# Arquitectura del Plugin WooCommerce ePayco

## Índice

1. [Visión General](#1-visión-general)
2. [Diagrama de Componentes](#2-diagrama-de-componentes)
3. [Diagrama de Clases Principal](#3-diagrama-de-clases-principal)
4. [Flujo de Inicialización del Plugin](#4-flujo-de-inicialización-del-plugin)
5. [Flujo de Pago](#5-flujo-de-pago)
6. [Arquitectura de Gateways](#6-arquitectura-de-gateways)
7. [Arquitectura de Bloques (WooCommerce Blocks)](#7-arquitectura-de-bloques-woocommerce-blocks)
8. [Arquitectura de Transacciones](#8-arquitectura-de-transacciones)
9. [Sistema de Hooks](#9-sistema-de-hooks)
10. [Inyección de Dependencias](#10-inyección-de-dependencias)
11. [Autenticación y Configuración](#11-autenticación-y-configuración)
12. [Integración con APIs Externas](#12-integración-con-apis-externas)

---

## 1. Visión General

El plugin ePayco para WooCommerce es una integración de pagos colombiana que soporta múltiples métodos de pago. Está construido sobre el sistema de plugins de WordPress, extiende WooCommerce mediante sus gateways de pago y soporta la nueva arquitectura de bloques (Gutenberg).

```mermaid
graph TB
    subgraph WordPress["WordPress Core"]
        WP[WordPress Hooks System]
    end

    subgraph WooCommerce["WooCommerce"]
        WCG[Payment Gateways API]
        WCB[Blocks API]
        WCO[Orders API]
    end

    subgraph Plugin["Plugin woocommerce-epayco-api"]
        EP[WoocommerceEpayco<br/>Main Class]
        GW[Gateways<br/>6 métodos de pago]
        BK[Blocks<br/>6 bloques checkout]
        TX[Transactions<br/>Procesadores]
        HK[Hooks<br/>Manejadores]
        CF[Configs<br/>Store + Seller]
    end

    subgraph EpaycoAPI["ePayco External APIs"]
        AUTH[Auth Service<br/>eks-apify-service]
        PMETHODS[Payment Methods<br/>eks-cms-backend]
        SDK[ePayco PHP SDK]
    end

    WordPress --> Plugin
    WooCommerce --> Plugin
    Plugin --> EpaycoAPI
    WCG --> GW
    WCB --> BK
    WCO --> TX
```

---

## 2. Diagrama de Componentes

```mermaid
graph LR
    subgraph EntryPoint["Entry Point"]
        MAIN[woocommerce-epayco.php]
        STARTUP[Startup.php]
    end

    subgraph Core["Core"]
        WE[WoocommerceEpayco]
        DEP[Dependencies]
    end

    subgraph PaymentStack["Payment Stack"]
        direction TB
        GW[Gateways<br/>AbstractGateway]
        TX[Transactions<br/>AbstractTransaction]
        BK[Blocks<br/>AbstractBlock]
    end

    subgraph Infrastructure["Infrastructure"]
        direction TB
        HK[Hooks Container]
        CF[Configs<br/>Store + Seller]
        HL[Helpers<br/>12 clases]
        TR[Translations<br/>Admin + Store]
    end

    subgraph HooksModules["Módulos de Hooks"]
        direction TB
        HK_GW[Gateway]
        HK_OR[Order]
        HK_EP[Epayco SDK]
        HK_AU[Authentication]
        HK_EN[Endpoints]
        HK_CH[Checkout]
        HK_SC[Scripts]
        HK_BL[Blocks]
        HK_AD[Admin]
    end

    MAIN --> STARTUP
    MAIN --> WE
    WE --> DEP
    DEP --> PaymentStack
    DEP --> Infrastructure
    HK --> HooksModules
    Infrastructure --> HK
```

---

## 3. Diagrama de Clases Principal

```mermaid
classDiagram
    class WoocommerceEpayco {
        +WooCommerce $woocommerce
        +Hooks $hooks
        +Settings $settings
        +Helpers $helpers
        +OrderMetadata $orderMetadata
        +AdminTranslations $adminTranslations
        +StoreTranslations $storeTranslations
        +Store $storeConfig
        +Seller $sellerConfig
        +Funnel $funnel
        +__construct()
        +init()
        +registerGateways()
        +registerBlocks()
        +setProperties()
        +activatePlugin()
        +disablePlugin()
    }

    class Dependencies {
        -WoocommerceEpayco $epayco
        +__construct(WoocommerceEpayco)
        +setStore()
        +setSeller()
        +setGateway()
        +setOrder()
        +setHooks()
        +setHelpers()
    }

    class AbstractGateway {
        <<abstract>>
        +string ID$
        +string CHECKOUT_NAME$
        +string WEBHOOK_API_NAME$
        +string LOG_SOURCE$
        +string $epaycoToken
        +array $epaycoPaymentMethods
        +WoocommerceEpayco $epayco
        +__construct()
        +process_payment(int orderId)*
        +webhook()
        +registerCheckoutScripts()
        +refundOrderGateway()
        +getSdkInstance()
        +getPaymentMethods(token)
        +extractCheckoutData()
    }

    class AbstractTransaction {
        <<abstract>>
        #WoocommerceEpayco $epayco
        #AbstractGateway $gateway
        +EpaycoSdk $sdk
        +__construct(gateway, order, checkout)
        +getSdkInstance()
    }

    class AbstractBlock {
        <<abstract>>
        #string $name
        #WoocommerceEpayco $epayco
        #EpaycoGatewayInterface $gateway
        +initialize()
        +is_active()
        +get_payment_method_script_handles()
        +get_payment_method_data()
        +setGateway()
        +resetCheckoutSession()
        +getScriptParams()*
    }

    class Hooks {
        +Admin $admin
        +Blocks $blocks
        +Checkout $checkout
        +Endpoints $endpoints
        +Gateway $gateway
        +Options $options
        +Order $order
        +Plugin $plugin
        +Scripts $scripts
        +Template $template
        +Cron $cron
    }

    class Seller {
        -Cache $cache
        -Options $options
        +getCredentialsPCustId()
        +getCredentialsPublicKeyPayment()
        +getCredentialsPrivateKeyPayment()
        +getCredentialsPkey()
        +validateEpaycoCredentials()
        +isTestMode()
    }

    class Store {
        -Options $options
        +getAvailablePaymentGateways()
        +addAvailablePaymentGateway()
        +isTestMode()
        +getCronSyncMode()
    }

    WoocommerceEpayco --> Dependencies : creates via
    WoocommerceEpayco --> Hooks : uses
    WoocommerceEpayco --> Seller : uses
    WoocommerceEpayco --> Store : uses
    Dependencies --> Hooks : builds
    Dependencies --> Seller : builds
    Dependencies --> Store : builds
    AbstractGateway --> WoocommerceEpayco : ref global
    AbstractTransaction --> WoocommerceEpayco : ref global
    AbstractTransaction --> AbstractGateway : uses
    AbstractBlock --> WoocommerceEpayco : ref global
    AbstractBlock --> AbstractGateway : resolves
```

---

## 4. Flujo de Inicialización del Plugin

```mermaid
sequenceDiagram
    participant WP as WordPress
    participant MAIN as woocommerce-epayco.php
    participant STARTUP as Startup
    participant WE as WoocommerceEpayco
    participant DEP as Dependencies
    participant STORE as Store Config
    participant SELLER as Seller Config
    participant GW as Gateway Hook
    participant EPAYCO as ePayco API

    WP->>MAIN: require_once (autoload)
    MAIN->>STARTUP: available()
    STARTUP-->>MAIN: vendor/autoload.php exists?
    MAIN->>WE: new WoocommerceEpayco()
    WE->>WE: defineConstants()
    WE->>WE: loadPluginTextDomain()
    WE->>WP: add_action('plugins_loaded', init)

    WP->>WE: plugins_loaded → init()
    WE->>DEP: new Dependencies(this)
    DEP->>STORE: new Store(options)
    DEP->>SELLER: new Seller(cache, options)
    DEP->>GW: new Gateway(store, url, funnel)
    DEP-->>WE: setProperties() complete

    WE->>EPAYCO: registerGateways() → fetch enabled methods
    EPAYCO-->>WE: array of gateway class names
    loop Por cada gateway habilitado
        WE->>GW: registerGateway(gatewayClass)
        GW->>WP: add_filter('woocommerce_payment_gateways')
    end

    WE->>WP: registerBlocks() → add_action('woocommerce_blocks_loaded')
```

---

## 5. Flujo de Pago

```mermaid
sequenceDiagram
    actor CUSTOMER as Cliente
    participant WC as WooCommerce
    participant BLOCK as AbstractBlock
    participant GW as AbstractGateway
    participant TX as AbstractTransaction
    participant SDK as Epayco SDK
    participant API as ePayco API
    participant ORDER as WC_Order

    CUSTOMER->>WC: Selecciona método de pago
    WC->>BLOCK: get_payment_method_data()
    BLOCK->>GW: registerCheckoutScripts()
    GW->>SDK: getSdkInstance()
    GW->>API: Auth → bearer token
    GW->>API: getPaymentMethods(token)
    API-->>GW: franchises / banks / etc.
    GW-->>BLOCK: script params con métodos disponibles
    BLOCK-->>CUSTOMER: Formulario de pago renderizado

    CUSTOMER->>WC: Confirma compra
    WC->>GW: process_payment(orderId)
    GW->>TX: new *Transaction(gateway, order, checkout)
    TX->>SDK: getSdkInstance()
    TX->>API: create charge / payment
    API-->>TX: response (redirectUrl / result)
    TX-->>GW: payment response
    GW->>ORDER: set status 'pending'
    GW-->>WC: redirect URL

    CUSTOMER->>GW: Retorno desde ePayco (webhook)
    GW->>GW: webhook() → extractPostData()
    GW->>GW: authSignature() → valida x-signature
    alt Pago aprobado (cod_state = 1)
        GW->>ORDER: payment_complete()
        GW->>ORDER: add_order_note("Aprobado")
    else Pago rechazado / pendiente
        GW->>ORDER: update_status('failed'/'on-hold')
        GW->>ORDER: add_order_note(reason)
    end
    GW->>ORDER: update_meta(refPayco, fecha, modo)
```

---

## 6. Arquitectura de Gateways

```mermaid
classDiagram
    class WC_Payment_Gateway {
        <<WooCommerce Core>>
        +process_payment()
        +init_form_fields()
        +init_settings()
    }

    class EpaycoGatewayInterface {
        <<interface>>
        +process_payment(orderId)*
        +webhook()*
    }

    class AbstractGateway {
        <<abstract>>
        +ID : string
        +CHECKOUT_NAME : string
        +WEBHOOK_API_NAME : string
        +LOG_SOURCE : string
        +epaycoToken : string
        +epaycoPaymentMethods : array
        +registerCheckoutScripts()
        +getSdkInstance()
        +getPaymentMethods(token)
        +webhook()
        +refundOrderGateway()
        +extractCheckoutData()
        +process_payment(orderId)*
    }

    class CheckoutGateway {
        +ID = "woo-epayco-checkout"
        +process_payment(orderId)
    }

    class CreditCardGateway {
        +ID = "woo-epayco-creditcard"
        +process_payment(orderId)
    }

    class PseGateway {
        +ID = "woo-epayco-pse"
        +process_payment(orderId)
    }

    class TicketGateway {
        +ID = "woo-epayco-ticket"
        +process_payment(orderId)
    }

    class DaviplataGateway {
        +ID = "woo-epayco-daviplata"
        +process_payment(orderId)
    }

    class SubscriptionGateway {
        +ID = "woo-epayco-subscription"
        +process_payment(orderId)
    }

    WC_Payment_Gateway <|-- AbstractGateway
    EpaycoGatewayInterface <|.. AbstractGateway
    AbstractGateway <|-- CheckoutGateway
    AbstractGateway <|-- CreditCardGateway
    AbstractGateway <|-- PseGateway
    AbstractGateway <|-- TicketGateway
    AbstractGateway <|-- DaviplataGateway
    AbstractGateway <|-- SubscriptionGateway
```

---

## 7. Arquitectura de Bloques (WooCommerce Blocks)

```mermaid
classDiagram
    class AbstractPaymentMethodType {
        <<WooCommerce Blocks Core>>
        +initialize()
        +is_active()
        +get_payment_method_script_handles()
        +get_payment_method_data()
    }

    class EpaycoPaymentBlockInterface {
        <<interface>>
        +getScriptParams()*
        +setGateway()*
    }

    class AbstractBlock {
        <<abstract>>
        +ACTION_SESSION_KEY : string
        +GATEWAY_SESSION_KEY : string
        #name : string
        #scriptName : string
        #settings : array
        #epayco : WoocommerceEpayco
        #gateway : EpaycoGatewayInterface
        +initialize()
        +is_active()
        +get_payment_method_script_handles()
        +get_payment_method_data()
        +setGateway()
        +resetCheckoutSession()
        +updateCartToRegisterDiscountAndCommission()
        +getScriptParams()*
    }

    class CheckoutBlock {
        +name = "woo-epayco-checkout"
        +scriptName = "epayco-checkout-blocks"
        +getScriptParams()
    }

    class CreditCardBlock {
        +name = "woo-epayco-creditcard"
        +scriptName = "epayco-creditcard-blocks"
        +getScriptParams()
    }

    class PseBlock {
        +name = "woo-epayco-pse"
        +getScriptParams()
    }

    class TicketBlock {
        +name = "woo-epayco-ticket"
        +getScriptParams()
    }

    class DaviplataBlock {
        +name = "woo-epayco-daviplata"
        +getScriptParams()
    }

    class SubscriptionBlock {
        +name = "woo-epayco-subscription"
        +getScriptParams()
    }

    AbstractPaymentMethodType <|-- AbstractBlock
    EpaycoPaymentBlockInterface <|.. AbstractBlock
    AbstractBlock <|-- CheckoutBlock
    AbstractBlock <|-- CreditCardBlock
    AbstractBlock <|-- PseBlock
    AbstractBlock <|-- TicketBlock
    AbstractBlock <|-- DaviplataBlock
    AbstractBlock <|-- SubscriptionBlock
```

---

## 8. Arquitectura de Transacciones

```mermaid
classDiagram
    class AbstractTransaction {
        <<abstract>>
        #epayco : WoocommerceEpayco
        #gateway : AbstractGateway
        +sdk : EpaycoSdk
        +__construct(gateway, order, checkout)
        +getSdkInstance()
    }

    class AbstractPaymentTransaction {
        <<abstract>>
        +buildPayload(order, checkout)*
        +execute()*
    }

    class CreditCardTransaction {
        +ID = "credit_card"
        +buildPayload(order, checkout)
        +execute()
    }

    class PseTransaction {
        +ID = "pse"
        +buildPayload(order, checkout)
        +execute()
    }

    class TicketTransaction {
        +ID = "ticket"
        +buildPayload(order, checkout)
        +execute()
    }

    class DaviplataTransaction {
        +ID = "daviplata"
        +buildPayload(order, checkout)
        +execute()
    }

    class SubscriptionTransaction {
        +ID = "subscription"
        +buildPayload(order, checkout)
        +execute()
    }

    class EpaycoSdk {
        +charge
        +token
        +customer
        +bank
        +cash
        +plan
        +subscriptions
        +authentication
    }

    AbstractTransaction <|-- AbstractPaymentTransaction
    AbstractPaymentTransaction <|-- CreditCardTransaction
    AbstractPaymentTransaction <|-- PseTransaction
    AbstractPaymentTransaction <|-- TicketTransaction
    AbstractPaymentTransaction <|-- DaviplataTransaction
    AbstractPaymentTransaction <|-- SubscriptionTransaction
    AbstractTransaction --> EpaycoSdk : creates
```

---

## 9. Sistema de Hooks

```mermaid
graph TB
    subgraph HooksContainer["Hooks Container (src/Hooks.php)"]
        HC[Hooks]
    end

    subgraph HookModules["Módulos de Hooks"]
        ADM[Admin<br/>ajustes admin WP]
        BLK[Blocks<br/>registro de bloques]
        CHK[Checkout<br/>orden gateways]
        END[Endpoints<br/>wp_ajax / wc_ajax / woocommerce_api]
        GWY[Gateway<br/>registro + lifecycle]
        OPT[Options<br/>WP options]
        ORD[Order<br/>sync pedidos + cron]
        PLG[Plugin<br/>activate / deactivate]
        SCR[Scripts<br/>enqueue JS/CSS]
        TPL[Template<br/>render templates]
        CRN[Cron<br/>tareas programadas]
    end

    subgraph SpecializedHooks["Hooks Especializados"]
        AUTH[Authentication<br/>bearer token cookie]
        EPKSD[Epayco SDK<br/>wrapper API]
        BANK[Bank<br/>PSE específico]
        CASH[Cash<br/>Ticket/efectivo]
        CCRD[CreditCard<br/>tarjeta crédito]
        DPLT[Daviplata<br/>billetera digital]
        SFTP[Safetypay<br/>SafetyPay]
        SUBS[Subscriptions<br/>WC Subscriptions]
        TOKN[Token<br/>tokenización tarjetas]
        CLNT[Client<br/>datos cliente]
        PLAN[Plan<br/>planes suscripción]
        TXHK[Transaction<br/>callbacks transacción]
    end

    HC --> ADM & BLK & CHK & END & GWY & OPT & ORD & PLG & SCR & TPL & CRN
    GWY --> AUTH
    GWY --> EPKSD
    ORD --> BANK & CASH & CCRD & DPLT & SFTP & SUBS & TOKN & CLNT & PLAN & TXHK

    subgraph WordPressHooks["WordPress / WooCommerce Hooks"]
        WP1[plugins_loaded]
        WP2[woocommerce_payment_gateways]
        WP3[woocommerce_blocks_loaded]
        WP4[wp_ajax_*]
        WP5[woocommerce_api_*]
        WP6[wc_ajax_*]
        WP7[woocommerce_gateway_sort]
    end

    PLG --> WP1
    GWY --> WP2
    BLK --> WP3
    END --> WP4 & WP5 & WP6
    CHK --> WP7
```

---

## 10. Inyección de Dependencias

```mermaid
graph TB
    subgraph DI["Dependencies (src/Dependencies.php)"]
        direction TB

        subgraph configs["Configuración"]
            OPT[Options Hook]
            STORE[Store Config]
            SELLER[Seller Config]
        end

        subgraph helpers["Helpers"]
            CACHE[Cache]
            SESSION[Session]
            URL[Url]
            NOTICES[Notices]
            PMETHODS[PaymentMethods]
            STRINGS[Strings]
            CURRENTUSER[CurrentUser]
            GATEWAYSH[Gateways Helper]
        end

        subgraph hookModules["Módulos de Hooks"]
            HADM[Admin]
            HBLK[Blocks]
            HCHK[Checkout]
            HEND[Endpoints]
            HGWY[Gateway]
            HOPT[Options]
            HORD[Order]
            HPLG[Plugin]
            HSCR[Scripts]
            HTPL[Template]
            HCRN[Cron]
        end

        subgraph composites["Objetos Compuestos"]
            HOOKS[Hooks Container]
            HELPRS[Helpers Container]
            ORDMETA[OrderMetadata]
            FUNNEL[Funnel]
        end
    end

    OPT --> STORE
    OPT --> SELLER
    CACHE --> SELLER

    STORE & URL & FUNNEL --> HGWY
    HTPL & ORDMETA & URL & HEND & HCRN & CURRENTUSER --> HORD

    HADM & HBLK & HCHK & HEND & HGWY & HOPT & HORD & HPLG & HSCR & HTPL & HCRN --> HOOKS
    PMETHODS & SESSION & URL & NOTICES --> HELPRS

    HOOKS --> WE[WoocommerceEpayco]
    HELPRS --> WE
    STORE --> WE
    SELLER --> WE
```

---

## 11. Autenticación y Configuración

```mermaid
sequenceDiagram
    participant GW as AbstractGateway
    participant AUTH as Authentication Hook
    participant SELLER as Seller Config
    participant COOKIE as Browser Cookie
    participant APIFY as eks-apify-service.epayco.io
    participant CMSAPI as eks-cms-backend.epayco.io

    GW->>AUTH: Auth(apify=true)
    AUTH->>COOKIE: read cookie "{api_key}_apify"
    alt Cookie válida (no expirada)
        COOKIE-->>AUTH: bearer token existente
    else Cookie expirada o no existe
        AUTH->>SELLER: getCredentialsPublicKeyPayment()
        AUTH->>SELLER: getCredentialsPrivateKeyPayment()
        SELLER-->>AUTH: public_key, private_key
        AUTH->>APIFY: POST /login (base64 credentials)
        APIFY-->>AUTH: bearer token
        AUTH->>COOKIE: setcookie(14 min expiry)
    end
    AUTH-->>GW: bearer token

    GW->>CMSAPI: GET /payment/methods (Authorization: Bearer token)
    CMSAPI-->>GW: array de franchises/bancos/etc.

    GW->>CMSAPI: GET /woocommerce/payments (enabled gateways)
    CMSAPI-->>GW: array de gateway class names habilitados
```

---

## 12. Integración con APIs Externas

```mermaid
graph LR
    subgraph Plugin["Plugin"]
        SELLER[Seller Config<br/>credenciales]
        GW[AbstractGateway]
        TX[Transactions]
        ORDER[Order Hook]
    end

    subgraph EpaycoServices["Servicios ePayco"]
        APIFY["eks-apify-service.epayco.io<br/>POST /login → bearer token"]
        CMS["eks-cms-backend-platforms-service.epayco.io<br/>GET /payment/methods<br/>GET /woocommerce/payments"]
        SDK["ePayco PHP SDK<br/>charge · token · customer<br/>bank · cash · plan · subscriptions"]
    end

    subgraph DataFlow["Flujo de Datos"]
        direction TB
        CREDS["Credenciales<br/>public_key · private_key<br/>customer_id · p_key"]
        TOKEN["Bearer Token<br/>(cookie 14 min)"]
        METHODS["Métodos habilitados<br/>(franchise list)"]
        CHARGE["Cobro<br/>(ref_payco · estado)"]
    end

    SELLER --> CREDS
    CREDS --> APIFY
    APIFY --> TOKEN
    TOKEN --> CMS
    CMS --> METHODS
    METHODS --> GW

    TX --> SDK
    SDK --> CHARGE
    CHARGE --> ORDER

    style APIFY fill:#e8f4f8
    style CMS fill:#e8f4f8
    style SDK fill:#e8f4f8
```

---

## Resumen de la Estructura de Archivos

```
woocommerce-epayco-api/
├── woocommerce-epayco.php        ← Entry point
├── composer.json                 ← PSR-4: Epayco\Woocommerce\ → src/
├── uninstall.php
├── src/
│   ├── WoocommerceEpayco.php     ← Orquestador principal
│   ├── Dependencies.php          ← Contenedor DI / fábrica
│   ├── Startup.php               ← Verificación de dependencias
│   ├── Hooks.php                 ← Contenedor de hooks
│   ├── Helpers.php               ← Contenedor de helpers
│   ├── Admin/Settings.php        ← Configuración en WP Admin
│   ├── Blocks/                   ← 6 bloques Gutenberg
│   ├── Configs/                  ← Store.php + Seller.php
│   ├── Exceptions/               ← 3 excepciones custom
│   ├── Funnel/                   ← Asistente de configuración
│   ├── Gateways/                 ← 6 gateways de pago
│   ├── Helpers/                  ← 13 clases utilitarias
│   ├── Hooks/                    ← 24 módulos de hooks
│   ├── Interfaces/               ← 2 interfaces
│   ├── Order/OrderMetadata.php   ← Metadata de pedidos
│   ├── Transactions/             ← 5 procesadores de transacción
│   ├── Translations/             ← Admin + Store translations
│   └── Utils/                    ← Encriptación AES/OpenSSL
├── assets/                       ← JS, CSS, imágenes
├── build/                        ← Assets compilados (bloques)
├── templates/                    ← Plantillas PHP
└── i18n/languages/               ← Archivos .po/.mo
```
