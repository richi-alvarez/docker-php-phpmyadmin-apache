# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Plugin Overview

ePayco payment gateway plugin for WooCommerce. Requires PHP 7.4+, WooCommerce 8.8.5+, tested up to WC 9.4.3.

- **Namespace:** `Epayco\Woocommerce\` (PSR-4, mapped to `src/`)
- **Text domain:** `woo-epayco-api`
- **Entry point:** `woocommerce-epayco.php`

## Architecture

### Initialization Flow

1. `woocommerce-epayco.php` — checks `vendor/autoload.php` via `Startup::available()`, declares WooCommerce compatibility (HPOS + Blocks)
2. `WoocommerceEpayco::__construct()` — defines constants, loads text domain, registers activation/deactivation hooks
3. `WoocommerceEpayco::init()` — fires on `plugins_loaded`; instantiates all dependencies via `setProperties()`
4. `registerGateways()` — fetches enabled payment methods from ePayco API and registers them with WooCommerce
5. `registerBlocks()` — registers WooCommerce Blocks (Gutenberg checkout) integration

### Key Classes

| Class | Role |
|-------|------|
| `src/WoocommerceEpayco.php` | Main orchestrator; holds references to all plugin components |
| `src/Hooks.php` | Container aggregating all hook handler instances |
| `src/Gateways/AbstractGateway.php` | Extends `WC_Payment_Gateway`; base for all payment gateways |
| `src/Transactions/AbstractTransaction.php` | Initializes ePayco SDK with seller credentials; base for transaction processors |
| `src/Blocks/AbstractBlock.php` | Base for WooCommerce Blocks payment integrations |
| `src/Configs/Seller.php` | Merchant credentials: customer ID, public/private API keys, test mode |
| `src/Configs/Store.php` | Site-level configuration |
| `src/Hooks/Authentication.php` | Validates `x-signature` on ePayco payment return |
| `src/Hooks/Epayco.php` | SDK wrapper used to call the ePayco API |

### Payment Methods

Each method has three parallel files: `Gateways/`, `Transactions/`, and `Blocks/`:

| Method | Description |
|--------|-------------|
| `Checkout` | Hosted checkout redirect |
| `CreditCard` | Direct card payment (Visa, MasterCard, Amex, Diners, Codensa) |
| `Pse` | Colombian bank transfer |
| `Ticket` | Cash/ticket payment |
| `Daviplata` | Colombian digital wallet |
| `Subscription` | Recurring billing (requires WooCommerce Subscriptions plugin) |

### Payment Flow

1. Customer selects method → `AbstractGateway::process_payment()` is called
2. Gateway instantiates the corresponding `*Transaction` class → calls ePayco SDK via `Hooks/Epayco.php`
3. ePayco returns a redirect URL (hosted) or a direct response
4. On return, `Hooks/Authentication.php` validates the `x-signature`
5. Order status is updated based on `x-cod-transaction-state`

### Hooks Architecture

`src/Hooks/` has one class per concern: `Admin`, `Authentication`, `Bank`, `Blocks`, `Cash`, `Checkout`, `Client`, `CreditCard`, `Customers`, `Daviplata`, `Endpoints`, `Gateway`, `Options`, `Order`, `OrderMeta`, `Plan`, `Plugin`, `Resource`, `Safetypay`, `Scripts`, `Subscriptions`, `Template`, `Token`, `Transaction`. All are wired together through the `Hooks` container.

### Utilities

- `src/Utils/PaycoAes.php`, `OpensslEncrypt.php`, `McryptEncrypt.php` — encryption utilities used for signature validation
- `src/Helpers/` — 13 helper classes: `Cache`, `Cron`, `CurrentUser`, `Form`, `Gateways`, `Notices`, `Paths`, `PaymentMethods`, `PaymentStatus`, `Session`, `Strings`, `Template`, `Url`
- `src/Exceptions/` — `InvalidCheckoutDataException`, `RejectedPaymentException`, `ResponseStatusException`
