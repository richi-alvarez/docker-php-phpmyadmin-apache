<?php

/**
 * Part of Woo Epayco Module
 * Author - Epayco
 * Developer
 * Copyright - Copyright(c) Epayco [https://www.epayco.com]
 * License - https://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 *
 * @package Epayco
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<div id="epayco-cms-detail-purchase"></div>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        oPenDetailPurchase()
    });
    function oPenDetailPurchase(){
      console.log("<?php echo esc_html($lang); ?>")
      console.log("<?php echo esc_html($refPayco); ?>")
      console.log("<?php echo esc_html($expirationDate); ?>")
      console.log("<?php echo esc_html($codeProject); ?>")
      console.log("<?php echo esc_html($pin); ?>")
        if (window.DetailPurchase) {
            DetailPurchase.config({
            referencePayco:<?php echo esc_html($refPayco); ?>,
            expirationDate:"<?php echo esc_html($expirationDate); ?>",
            codeProject:"<?php echo esc_html($codeProject); ?>",
            pin:"<?php echo esc_html($pin); ?>",
           sendEmail:true,
           lang:"<?php echo esc_html($lang); ?>"
          });
        } else {
          console.error("DetailPurchase no está cargado todavía");
        }
    }
  </script>