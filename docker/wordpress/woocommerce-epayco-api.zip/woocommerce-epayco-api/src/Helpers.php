<?php

namespace Epayco\Woocommerce;
use Epayco\Woocommerce\Helpers\Notices;
use Epayco\Woocommerce\Helpers\PaymentMethods;
use Epayco\Woocommerce\Helpers\Session;
use Epayco\Woocommerce\Helpers\Url;

if (!defined('ABSPATH')) {
    exit;
}

class Helpers
{
    public PaymentMethods $paymentMethods;

    public Session $session;

    public Url $url;

    public Notices $notices;

    public function __construct(
        PaymentMethods $paymentMethods,
        Session $session,
        Url $url,
        Notices $notices
    ){
        $this->paymentMethods = $paymentMethods;
        $this->session        = $session;
        $this->url      = $url;
        $this->notices        = $notices;
    }
}