<?php

namespace Epayco\Woocommerce\Blocks;

if (!defined('ABSPATH')) {
    exit;
}

class PseAgregadorBlock extends PseBlock
{
    protected $scriptName = 'pse-agregador';

    protected $name = 'woo-epayco-pse-agregador';

    public function initialize(): void
    {
        $this->settings = get_option('woocommerce_woo-epayco-pse_settings', []);
    }

    public function is_active(): bool
    {
        return ($this->settings['enabled_agregador'] ?? 'no') === 'yes';
    }

    public function get_payment_method_data(): array
    {
        $data = parent::get_payment_method_data();
        if (isset($this->gateway) && !empty($this->gateway->title)) {
            $data['title'] = $this->gateway->title;
        } else {
            $data['title'] = ($data['title'] ?: 'ePayco - Pago PSE') . ' (Agregador)';
        }
        return $data;
    }
}
