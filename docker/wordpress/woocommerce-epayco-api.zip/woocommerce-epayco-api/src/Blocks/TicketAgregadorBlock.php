<?php

namespace Epayco\Woocommerce\Blocks;

if (!defined('ABSPATH')) {
    exit;
}

class TicketAgregadorBlock extends TicketBlock
{
    protected $scriptName = 'ticket-agregador';

    protected $name = 'woo-epayco-ticket-agregador';

    public function initialize(): void
    {
        // Load settings from the ORIGINAL gateway (not the -agregador key)
        $this->settings = get_option('woocommerce_woo-epayco-ticket_settings', []);
    }

    public function is_active(): bool
    {
        return ($this->settings['enabled_agregador'] ?? 'no') === 'yes';
    }

    public function get_payment_method_data(): array
    {
        $data = parent::get_payment_method_data();
        // Gateway instance has the correct title (with " (Agregador)" already appended)
        if (isset($this->gateway) && !empty($this->gateway->title)) {
            $data['title'] = $this->gateway->title;
        } else {
            $data['title'] = ($data['title'] ?: 'ePayco - Pago Efectivo') . ' (Agregador)';
        }
        return $data;
    }
}
