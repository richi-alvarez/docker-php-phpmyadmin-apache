<?php

namespace Epayco\Woocommerce\Blocks;

if (!defined('ABSPATH')) {
    exit;
}

class CreditCardAgregadorBlock extends CreditCardBlock
{
    protected $scriptName = 'creditcard-agregador';

    protected $name = 'woo-epayco-creditcard-agregador';

    public function initialize(): void
    {
        $this->settings = get_option('woocommerce_woo-epayco-creditcard_settings', []);
    }

    public function is_active(): bool
    {
        return ($this->settings['enabled_agregador'] ?? 'no') === 'yes';
    }

    public function get_payment_method_data(): array
    {
        $data = parent::get_payment_method_data();
        if (isset($this->gateway) && !empty($this->gateway->title)) {
            $data['title'] = $this->gateway->title;
        } else {
            $data['title'] = ($data['title'] ?: 'ePayco - Pago Tarjeta de crédito y débito') . ' (Agregador)';
        }
        return $data;
    }
}
