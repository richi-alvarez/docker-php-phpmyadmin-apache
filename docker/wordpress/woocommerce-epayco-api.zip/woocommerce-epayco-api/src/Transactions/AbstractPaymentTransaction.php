<?php

namespace Epayco\Woocommerce\Transactions;

use Epayco\Woocommerce\Gateways\AbstractGateway;

abstract class AbstractPaymentTransaction extends AbstractTransaction
{
    /**
     * Payment Transaction constructor
     */
    public function __construct(AbstractGateway $gateway, ?\WC_Order $order, array $checkout)
    {
        parent::__construct($gateway, $order, $checkout);
    }

    /**
     * Create Payment
     *
     * @return string|array
     * @throws \Exception
     */
    public function createCashPayment($order_id, array $checkout)
    {
        $order = new \WC_Order($order_id);
        $descripcionParts = array();
        $getCheckoutValues = $this->getCheckoutValues($order);
        $iva = $getCheckoutValues['iva'];
        $ico = $getCheckoutValues['ico'];
        $base_tax = $getCheckoutValues['base_tax'];
        foreach ($order->get_items() as $product) {
            $clearData = str_replace('_', ' ', $this->string_sanitize($product['name']));
            $descripcionParts[] = $clearData;
        }

        $descripcion = implode(' - ', $descripcionParts);
        $currency = strtolower(get_woocommerce_currency());
        $basedCountry = WC()->countries->get_base_country()!='' ? WC()->countries->get_base_country():$order->get_shipping_country();
        //$basedCountry = $checkout["countryType"]??$checkout["countrytype"];
        $city = WC()->countries->get_base_city() !='' ? WC()->countries->get_base_city():$order->get_shipping_city();
        $myIp=$this->getCustomerIp();
        $confirm_url = $checkout["confirm_url"];
        $response_url = $checkout["confirm_url"];
        $end_date = gmdate( 'Y-m-d', strtotime( '+' . (int) $checkout['date_expiration'] . ' days' ) );
        $testMode = $this->epayco->storeConfig->isTestMode()??false;
        $customerName = $checkout["name"]??$checkout[""]["name"];
        $explodeName = explode(" ", $customerName);
        $name = $explodeName[0];
        $lastName = $explodeName[1];
        //$person_type= $checkout["person_type"];
        $person_type= 'PN';
        //$holder_address= $checkout["address"];
        $holder_address=$order->get_billing_address_1();
        $doc_type= $checkout["identificationtype"]??$checkout["identificationType"]??$checkout["documentType"];
        $doc_number= $checkout["doc_number"]??$checkout["document"]??$checkout[""]["doc_number"]??$_POST['docNumberError']??$_POST['identificationTypeError'];
        $email= $checkout["email"];
        $cellphone= $checkout["cellphone"];
        //$cellphone=@$order->billing_phone??'0';
        $data = array(
            //"paymentMethod" => $checkout["paymentMethod"],
            //"invoice" => (string)$order->get_id(),
            "invoice" => (string)$order->get_id().date('YmdHis'),
            "description" => $descripcion,
            "value" =>(string)$order->get_total(),
            "tax" => (string)$iva,
            "ico" => (string)$ico,
            "tax_base" => (string)$base_tax,
            "currency" => $currency,
            "type_person" => $person_type=='PN'?"0":"1",
            "address" => $holder_address,
            "doc_type" => $doc_type,
            "doc_number" => $doc_number,
            "name" => $name,
            "last_name" => $lastName,
            "email" => $email,
            "country" => $basedCountry,
            "city" => $city,
            "cell_phone" => $cellphone,
            "end_date" => $end_date,
            "ip" => $myIp,
            "url_response" => $response_url,
            "url_confirmation" => $confirm_url,
            "metodoconfirmacion" => "POST",
            "extra1" => (string)$order->get_id(),
           /* "extras" => array(
                "extra1" => (string)$order->get_id(),
            ),*/
            "vtex" => false,
            "testMode" => $testMode,
            "extras_epayco"=>["extra5"=>"P59"]
        );
        $cash = $this->sdk->cash->create($checkout["paymentMethod"],$data);
        $cash = json_decode(wp_json_encode($cash), true);
        return $cash;
    }

    /**
     * Create Payment
     *
     * @return string|array
     * @throws \Exception
     */
    public function createDaviplataPayment($order_id, array $checkout)
    {
        $order = new \WC_Order($order_id);
        $descripcionParts = array();
        $getCheckoutValues = $this->getCheckoutValues($order);
        $iva = $getCheckoutValues['iva'];
        $ico = $getCheckoutValues['ico'];
        $base_tax = $getCheckoutValues['base_tax'];
        foreach ($order->get_items() as $product) {
            $clearData = str_replace('_', ' ', $this->string_sanitize($product['name']));
            $descripcionParts[] = $clearData;
        }

        $descripcion = implode(' - ', $descripcionParts);
        $currency = strtolower(get_woocommerce_currency());
        //$basedCountry = WC()->countries->get_base_country();
        $basedCountry = 'CO';
        $myIp=$this->getCustomerIp();
        $confirm_url = $checkout["confirm_url"];
        $response_url = $checkout["response_url"];
        $customerName = $checkout["name"]??$checkout[""]["name"];
        $explodeName = explode(" ", $customerName);
        $name = $explodeName[0];
        $lastName = $explodeName[1];
        //$person_type= $checkout["person_type"]??$checkout[""]["person_type"];
        //$holder_address= $checkout["address"]??$checkout[""]["address"];
        $person_type= 'PN';
        $holder_address=$order->get_billing_address_1();
        $doc_type= $checkout["identificationtype"]??$checkout["identificationType"]??$checkout["documentType"];
        $doc_number= $checkout["doc_number"]??$checkout[""]["doc_number"]??$checkout["document"]??$_POST['docNumberError']??$_POST['identificationTypeError'];
        $email= $checkout["email"]??$checkout[""]["email"];
        $cellphonetype= $checkout["cellphonetype"]??$checkout[""]["cellphonetype"];
        $cellphone = $_POST["cellphone"]??$checkout["cellphone"]??$checkout[""]["cellphone"];
        $cellphonetypeIn = explode("+", $cellphonetype)[1];
        $city = WC()->countries->get_base_city() !='' ? WC()->countries->get_base_city():$order->get_shipping_city();
        $testMode = $this->epayco->storeConfig->isTestMode()??false;
        $data = array(
            //"invoice" => (string)$order->get_id(),
            "invoice" => (string)$order->get_id().date('YmdHis'),
            "description" => $descripcion,
            "value" =>(string)$order->get_total(),
            "tax" => (string)$iva,
            "taxBase" => (string)$base_tax,
            "currency" => strtoupper($currency),
            "type_person" => $person_type=='PN'?"0":"1",
            "address" => $holder_address,
            "docType" => $doc_type,
            "document" => $doc_number,
            "name" => $name,
            "lastName" => $lastName,
            "email" => $email,
            "country" => $basedCountry,
            "indCountry" => $cellphonetypeIn,
            "city" => $city,
            "phone" => $cellphone,
            "ip" => $myIp,
            "urlResponse" => $response_url,
            "urlConfirmation" => $confirm_url,
            "methodConfirmation" => "POST",
            "extra1" => (string)$order->get_id(),
            "vtex" => true,
            "testMode" => $testMode,
            "extras_epayco"=>["extra5"=>"P60"]
        );
        $daviplata = $this->sdk->daviplata->create($data);
        $daviplata= json_decode(wp_json_encode($daviplata), true);
        return $daviplata;
    }

    /**
     * Create Payment
     *
     * @return string|array
     * @throws \Exception
     */
    public function createTcPayment($order_id, array $checkout)
    {
        $order = new \WC_Order($order_id);
        $descripcionParts = array();
        $getCheckoutValues = $this->getCheckoutValues($order);
        $iva = $getCheckoutValues['iva'];
        $ico = $getCheckoutValues['ico'];
        $base_tax = $getCheckoutValues['base_tax'];
        foreach ($order->get_items() as $product) {
            $clearData = str_replace('_', ' ', $this->string_sanitize($product['name']));
            $descripcionParts[] = $clearData;
        }

        $descripcion = implode(' - ', $descripcionParts);
        $currency = strtolower(get_woocommerce_currency());
        $basedCountry = WC()->countries->get_base_country();
        //$customerData = $this->getCustomer($checkout);
        $basedCountry = $checkout["countryType"]??$checkout["countrytype"]??$checkout[""]["countryType"];
        $city = $checkout["country"]??$checkout[""]["country"];
        $myIp=$this->getCustomerIp();
        $confirm_url = $checkout["confirm_url"];
        $response_url = $checkout["response_url"];
        $testMode = $this->epayco->storeConfig->isTestMode()??false;
        $customerName = $checkout["name"]??$checkout[""]["name"];
        $explodeName = explode(" ", $customerName);
        $name = $explodeName[0];
        $lastName = $explodeName[1];
        $dues= $checkout["installmet"]??$checkout[""]["installmet"];
        //$person_type= $checkout["person_type"]??$checkout[""]["person_type"];
        $holder_address= $checkout["address"]??$checkout[""]["address"];
        $doc_type= $checkout["identificationtype"]??$checkout["identificationType"]??$checkout[""]["identificationType"];
        $doc_number= $checkout["doc_number"]??$checkout[""]["doc_number"]??$_POST['docNumberError']??$_POST['identificationTypeError'];
        $email= $checkout["email"]??$checkout[""]["email"];
        $cellphone= $checkout["cellphone"]??$checkout[""]["cellphone"];
        $date =  $checkout["expirationDate"] ?? $checkout["expirationdate"];
        list($month, $year) = explode("/", $date);
        $securityCode = $checkout["securityCode"] ?? $checkout["securitycode"];
        if (strlen($year) === 2) {
            $year = "20" . $year;
        } elseif (strlen($year) === 4) {
            // Si ya viene como 2029 lo dejamos igual
            $year = $year;
        } else {
            throw new \Exception("Formato de año no válido: " . $year);
        }
        $token = $this->sdk->token->create(array(
            "card[number]" => $checkout["card"],
            "card[exp_year]" => $year,
            "card[exp_month]" => $month,
            "card[cvc]" => $securityCode,
            "hasCvv" => true
        ));


        if(!$token['status']){
            $token['success'] = false;
            return $token;
        }
        $token_id = $token['id'];
        $checkout['token_card'] = $token_id;
        $checkout['token'] = $token_id;
        /*$customerData = $this->getCustomer($checkout);
        if(!$customerData['success']){
            return $customerData;
        }
        */
         sleep(1);
        $customer = $this->customerCreate($checkout);
        if (is_array($customer) && !$customer['success']) {
            $response_status = [
                'success' => false,
                'message' => $customer['message']
            ];
            return $response_status;
        }
        sleep(3);
        $customerId = $customer['data']['customerId'];
        $data = array(
            "token_card" => $token_id,
            "customer_id" => $customerId,
            //"customer_id" => 'customer_id',
            //"bill" => (string)$order->get_id(),
            "bill" => (string)$order->get_id().date('YmdHis'),
            "dues" => $dues,
            "description" => $descripcion,
            "value" =>(string)$order->get_total(),
            "tax" => $iva,
            "tax_base" => $base_tax,
            "currency" => $currency,
            "doc_type" => $doc_type,
            "doc_number" => $doc_number,
            "name" => $name,
            "last_name" => $lastName,
            "email" => $email,
            "country" => $basedCountry,
            "address"=> $holder_address,
            "city" => $city,
            "cell_phone" => $cellphone,
            "ip" => $myIp,
            "url_response" => $response_url,
            "url_confirmation" => $confirm_url,
            "metodoconfirmacion" => "POST",
            "use_default_card_customer" => true,
            "extra1" => (string)$order->get_id(),
            /*"extras" => array(
                "extra1" => (string)$order->get_id(),
            ),*/
            "extras_epayco"=>["extra5"=>"P55"]
        );
        $charge = $this->sdk->charge->create($data);
        return $charge;
    }

    /**
     * Create Payment
     *
     * @return string|array
     * @throws \Exception
     */
    public function createPsePayment($order_id, array $checkout)
    {
        $order = new \WC_Order($order_id);
        $descripcionParts = array();
        $getCheckoutValues = $this->getCheckoutValues($order);
        $iva = $getCheckoutValues['iva'];
        $ico = $getCheckoutValues['ico'];
        $base_tax = $getCheckoutValues['base_tax'];
        foreach ($order->get_items() as $product) {
            $clearData = str_replace('_', ' ', $this->string_sanitize($product['name']));
            $descripcionParts[] = $clearData;
        }

        $descripcion = implode(' - ', $descripcionParts);
        $currency = strtolower(get_woocommerce_currency());
        //$basedCountry = WC()->countries->get_base_country();
        $basedCountry = $checkout["countryType"]??$checkout["countrytype"]??$checkout[""]["countryType"];
        $city = $checkout["country"]??$checkout[""]["country"];
        $myIp=$this->getCustomerIp();
        $confirm_url = $checkout["confirm_url"];
        $response_url = $checkout["response_url"];
        $testMode = $this->epayco->storeConfig->isTestMode()??false;
        $customerName = $checkout["name"]??$checkout[""]["name"];
        $explodeName = explode(" ", $customerName);
        $name = $explodeName[0];
        $lastName = $explodeName[1];
        $bank = $checkout["bank"]??$checkout[""]["bank"];
        $person_type= $checkout["person_type"]??$checkout[""]["person_type"];
        $holder_address= $checkout["address"]??$checkout[""]["address"];
        $doc_type= $checkout["identificationtype"]??$checkout["identificationType"]??$checkout[""]["identificationType"]??$checkout["documentType"];
        $doc_number= $checkout["doc_number"]??$checkout[""]["doc_number"]??$checkout["document"]??$_POST['docNumberError']??$_POST['identificationTypeError'];
        $email= $checkout["email"]??$checkout[""]["email"];
        $cellphone= $checkout["cellphonetype"]??$checkout[""]["cellphonetype"]??$checkout["cellphone"];
        $data = array(
            "bank" => $bank,
            //"invoice" => (string)$order->get_id(),
            "invoice" => (string)$order->get_id().date('YmdHis'),
            "description" => $descripcion,
            "value" =>$order->get_total(),
            "tax" => $iva,
            "tax_base" => $base_tax,
            "currency" => $currency,
            "type_person" => $person_type=='PN'?"0":"1",
            "address" => $holder_address,
            "doc_type" => $doc_type,
            "doc_number" => $doc_number,
            "name" =>$name,
            "last_name" => $lastName,
            "email" => $email,
            "country" => $basedCountry,
            "city" => $city,
            "cell_phone" => $cellphone,
            "ip" => $myIp,
            "url_response" => $response_url,
            "url_confirmation" => $confirm_url,
            "metodoconfirmacion" => "POST",
            "extra1" => (string)$order->get_id(),
            /*"extras" => array(
                "extra1" => (string)$order->get_id(),
            ),*/
            //"testMode" => $testMode,
            "extras_epayco"=>["extra5"=>"P58"]
        );
        $pse = $this->sdk->bank->create($data);
        return $pse;
    }

    /**
     * Create Payment
     *
     * @return string|array
     * @throws \Exception
     */
    public function createSubscriptionPayment($order_id, array $checkout)
    {
      
        global $wpdb;
        $order = new \WC_Order($order_id);
        $subscriptions = wcs_get_subscriptions_for_order($order_id);
        $customerData = $this->getCustomer($checkout);
        if(!$customerData['success']){
            error_log("❌ getCustomer() failed: " . wp_json_encode($customerData));
            return $customerData;
        }
        $checkout['customer_id'] = $customerData['customer_id'];
        $customer = $this->paramsBilling($subscriptions, $order, $checkout);
        $plans = $this->getPlansBySubscription($subscriptions);
        $getPlans = $this->getPlans($plans);
        if (!$getPlans) {
            $validatePlan = $this->validatePlan(true, $order_id, $plans, $subscriptions, $customer, $order, false, false, null,$checkout);
        } else {
            $validatePlan = $this->validatePlan(false, $order_id, $plans, $subscriptions, $customer, $order, true, false, $getPlans,$checkout);
        }
        
        // Log validatePlan response
        if (class_exists('WC_Logger')) {
            $logger = wc_get_logger();
            if (!isset($validatePlan['success']) || !$validatePlan['success']) {
                $logger->error("Subscription payment failed");
            }
        }
        
        $errorMessage = array();
        if(!isset($validatePlan['success']) || !$validatePlan['success']){
            // Intentar obtener el mensaje de error de diferentes formatos de respuesta
            $errorDetails = '';
            
            if(is_array($validatePlan['message'] ?? null)){
                foreach ($validatePlan['message'] as $message) {
                    $errorMessage[] = $message;
                }
                $errorDetails = implode(' - ', $errorMessage);
            } elseif(isset($validatePlan['message'])){
                $errorDetails = $validatePlan['message'];
            } elseif(isset($validatePlan['data'])){
                // Si hay datos adicionales, incluirlos en el error
                $errorDetails = wp_json_encode($validatePlan['data']);
            }
            
            // Si no se encontró mensaje, mostrar toda la respuesta para debugging
            if(empty($errorDetails)){
                $errorDetails = 'Unknown error in validatePlan - Complete response: ' . wp_json_encode($validatePlan);
            }
            
            error_log("❌ validatePlan ERROR: " . wp_json_encode($validatePlan));
            return [
                'success' => false,
                'message' => $errorDetails
            ];
        }else{
            error_log("✓ validatePlan SUCCESS: " . wp_json_encode($validatePlan));
            return $validatePlan;
        }
    }

    public function getCustomer($customerData)
    {
        global $wpdb;
        $table_name_customer = $wpdb->prefix . 'epayco_customer';
        $customerGetData = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM $table_name_customer WHERE email = %s",
                trim($customerData['email'])
            )
        );
        if (count($customerGetData) == 0) {
            return $this->getCreateNewCustomer($customerData);
        }else{
            $count_customers = 0;
            for ($i = 0; $i < count($customerGetData); $i++) {
                if ($customerGetData[$i]->email == trim($customerData['email'])) {
                    $count_customers += 1;
                }
            }
            if ($count_customers == 0) {
                $customer = $this->customerCreate($customerData);
                if (is_array($customer) && !$customer['success']) {
                    $response_status = [
                        'success' => false,
                        'message' => $customer['message']
                    ];
                    return $response_status;
                }
                $inserCustomer = $wpdb->insert(
                    $table_name_customer,
                    [
                        'customer_id' => $customer['data']['customerId'],
                        'email' => trim($customerData['email'])
                    ]
                );
                if (!$inserCustomer) {
                    $response_status = [
                        'success' => false,
                        'message' => 'internar error, tray again'
                    ];
                    return $response_status;
                }
                $response_status = [
                    'success' => true,
                    'customer_id' => $customer['data']['customerId']
                ];
                return $response_status;
            } else {
                $count_cards = 0;
                for ($i = 0; $i < count($customerGetData); $i++) {
                    $customers = $this->sdk->customer->get($customerGetData[$i]->customer_id);
                    $customers = json_decode(wp_json_encode($customers), true);
                    if($customers['success']){
                        $cards = $customers['data']['cards'];
                        for ($j = 0; $j < count($cards); $j++) {
                            if ($cards[$j]['token'] == trim($customerData['token'])) {
                                $count_cards += 1;
                            }
                        }
                        if($count_cards == 0){
                            $this->customerAddToken($customerGetData[$i]->customer_id, trim($customerData['token']));
                        }
                    }else{
                        return $this->getCreateNewCustomer($customerData);
                    }
                    $customerData['customer_id'] = $customerGetData[$i]->customer_id;
                }
                $response_status = [
                    'success' => true,
                    'customer_id' => $customerData['customer_id']
                ];
                return $response_status;
            }
        }
    }

    public function getCreateNewCustomer($customerData)
    {
        global $wpdb;
        $table_name_customer = $wpdb->prefix . 'epayco_customer';
        $customer = $this->customerCreate($customerData);
        if (is_array($customer) && $customer['success']) {
            $inserCustomer = $wpdb->insert(
                $table_name_customer,
                [
                    'customer_id' => $customer['data']['customerId'],
                    'email' => trim($customerData['email'])
                ]
            );
            if (!$inserCustomer) {
                $response_status = [
                    'success' => false,
                    'message' => 'internar error, tray again'
                ];
                return $response_status;
            }{
                $response_status = [
                    'success' => true,
                    'customer_id' => $customer['data']['customerId']
                ];
                return $response_status;
            }
        }else{
            $messageError = $customer['message'];
            $errorMessage = "";
            if (isset($customer['data']['errors'])) {
                $errors = $customer['data']['errors'];
                if(is_array($errors)){
                    foreach ($errors as $error) {
                        $errorMessage = $error['errorMessage'] . "\n";
                    }
                }
                if(is_string($errors)){
                    $errorMessage = $errors . "\n";
                }
            } elseif (isset($customer['data']['error']['errores'])) {
                $errores = $customer['data']['error']['errores'];
                foreach ($errores as $error) {
                    $errorMessage = $error['errorMessage'] . "\n";
                }
            }
            $processReturnFailMessage = $messageError. " " . $errorMessage;
            $response_status = [
                'success' => false,
                'message' => $processReturnFailMessage
            ];
            return $response_status;
        }
    }

    public function customerCreate(array $data)
    {
        $customer = false;
        try {
            $customer = $this->sdk->customer->create(
                [
                    "token_card" => $data['token'],
                    "name" => $data['name'],
                    "email" => $data['email'],
                    "phone" => $data['cellphone'],
                    "cell_phone" => $data['cellphone'],
                    "country" => $data['countrytype'],
                    "address" => $data['address'],
                    "default" => true
                ]
            );
            $customer = json_decode(wp_json_encode($customer), true);
            return $customer;
        } catch (\Exception $exception) {
            return [
                'status' => false,
                'message' => 'create client: : ' . $exception->getMessage()
            ];
        }
    }

    public function customerAddToken($customer_id, $token_card)
    {
        $customer = false;
        try {
            $customer = $this->sdk->customer->addNewToken(
                [
                    "token_card" => $token_card,
                    "customer_id" => $customer_id
                ]
            );
            return $customer;
        } catch (\Exception $exception) {
            return [
                'status' => false,
                'message' => 'add token: ' . $exception->getMessage()
            ];
        }
    }

    public function getPlansBySubscription(array $subscriptions)
    {
        $plans = [];
        foreach ($subscriptions as $key => $subscription) {
            $total_discount = $subscription->get_total_discount();
            $order_currency = $subscription->get_currency();
            $products = $subscription->get_items();
            $product_plan = $this->getPlan($products);
            $product_name = $product_plan['name'];
            $product_id = $product_plan['id'];
            $trial_days = $this->getTrialDays($subscription);
            
            // Limpiar el nombre del producto removiendo guiones al inicio y final
            $product_name = trim($product_name, '-');
            
            // Plan ID es solo el nombre del producto en minúsculas (limpio)
            $plan_id = strtolower($product_name);
            $plan_name = trim(str_replace("-", " ", $product_name));
            $plans[] = array_merge(
                [
                    "id_plan" => $plan_id,
                    "name" => "Plan $plan_name",
                    "description" => "Plan $plan_name",
                    "currency" => $order_currency,
                ],
                [
                    "trial_days" => $trial_days
                ],
                $this->intervalAmount($subscription)
            );
        }
        return $plans;
    }

    public function getPlan($products)
    {
        $product_plan = [];

        $product_plan['name'] = '';
        $product_plan['id'] = 0;
        $product_plan['quantity'] = 0;

        foreach ($products as $product) {
            $product_plan['name'] .= "{$product['name']}-";
            $product_plan['id'] .= "{$product['product_id']}-";
            $product_plan['quantity'] .= $product['quantity'];
        }

        $product_plan['name'] = $this->cleanCharacters($product_plan['name']);

        return $product_plan;
    }

    public function validatePlan($create, $order_id, array $plans, $subscriptions, $customer, $order, $confirm, $update, $getPlans, $checkout)
    {
        $eXistPLan = null;
        
        if (class_exists('WC_Logger')) {
            $logger = wc_get_logger();
            $logger->info("=== VALIDATE PLAN START ===");
            $logger->info("Create: " . ($create ? 'true' : 'false'));
            $logger->info("Confirm: " . ($confirm ? 'true' : 'false'));
        }
        
        // PRIMERO: Intentar obtener el plan existente
        if (!$getPlans) {
            $existingPlan = $this->getPlans($plans);
            
            if (class_exists('WC_Logger')) {
                $logger = wc_get_logger();
                $logger->info("Checked for existing plan: " . ($existingPlan ? 'Found' : 'Not found'));
            }
            
            if ($existingPlan) {
                // El plan ya existe, usar directamente
                if (class_exists('WC_Logger')) {
                    $logger = wc_get_logger();
                    $logger->info("Using existing plan: " . wp_json_encode($existingPlan));
                }
                $getPlans = $existingPlan;
                $confirm = true;
            } elseif ($create) {
                // El plan no existe y se debe crear
                $newPLan = $this->plansCreate($plans);
                
                if (class_exists('WC_Logger')) {
                    $logger = wc_get_logger();
                    $logger->info("Plan creation response: " . wp_json_encode($newPLan));
                }
                
                // Handle both object and array responses
                $planStatus = is_object($newPLan) ? ($newPLan->status ?? false) : ($newPLan['status'] ?? false);
                $planMessage = is_object($newPLan) ? ($newPLan->message ?? '') : ($newPLan['message'] ?? '');
                
                if ($planStatus) {
                    // El plan fue creado exitosamente, esperamos un momento antes de intentar obtenerlo
                    sleep(2);
                    
                    $getPlans_ = $this->getPlans($plans);
                    
                    if (class_exists('WC_Logger')) {
                        $logger = wc_get_logger();
                        $logger->info("Get plans response after creation: " . ($getPlans_ ? 'Plan found' : 'Plan not found'));
                    }
                    
                    if ($getPlans_) {
                        $getPlans = $getPlans_;
                        $confirm = true;
                    } else {
                        // Si el plan se creó pero no se encuentra en la búsqueda, usar los datos del plan creado directamente
                        if (class_exists('WC_Logger')) {
                            $logger = wc_get_logger();
                            $logger->info("Plan created but not found in GET request. Using created plan data directly.");
                        }
                        
                        // El plan existe en ePayco, proceder con el pago de suscripción
                        $eXistPLan = $this->process_payment_epayco($plans, $customer, $subscriptions, $order, $checkout);
                    }
                } else {
                    $eXistPLan = [
                        'success' => false,
                        'message' => $planMessage ?? 'Error creating plan'
                    ];
                    
                    if (class_exists('WC_Logger')) {
                        $logger = wc_get_logger();
                        $logger->error("Plan creation failed: " . wp_json_encode($eXistPLan));
                    }
                }
            }
        }
        
        // SEGUNDO: Si confirmamos, procesar datos del plan
        if ($confirm && $getPlans && $eXistPLan === null) {
            $eXistPLan = $this->validatePlanData($plans, $getPlans, $order_id, $subscriptions, $customer, $order, $checkout);
        }
        
        // Ensure we always return an array
        if ($eXistPLan === null) {
            $eXistPLan = [
                'success' => false,
                'message' => 'Null response from validatePlan - no result assigned'
            ];
            
            if (class_exists('WC_Logger')) {
                $logger = wc_get_logger();
                $logger->error("validatePlan returned null - forcing error response");
            }
        }
        
        if (class_exists('WC_Logger')) {
            $logger = wc_get_logger();
            $logger->info("=== VALIDATE PLAN END ===");
            $logger->info("Final response: " . wp_json_encode($eXistPLan));
        }
        
        return $eXistPLan;
    }

    public function plansCreate(array $plans)
    {
        foreach ($plans as $plan) {
            try {
                $plan_ = $this->sdk->plan->create(
                    [
                        "id_plan" => (string)str_replace("-", "_",strtolower($plan['id_plan'])),
                        "name" => (string)$plan['name'],
                        "description" => (string)$plan['description'],
                        "amount" => $plan['amount'],
                        "currency" => $plan['currency'],
                        "interval" => $plan['interval'],
                        "interval_count" => $plan['interval_count'],
                        "trial_days" => $plan['trial_days']
                    ]
                );
                return $plan_;
            } catch (\Exception $exception) {
                return  [
                    'status' => false,
                    'message' => "create Plan: ".$exception->getMessage()
                ];
            }
        }
    }

    public function validatePlanData($plans, $getPlans, $order_id, $subscriptions, $customer, $order,$checkout)
    {
        foreach ($plans as $plan) {
            $plan_amount_cart = $plan['amount'];
            $plan_id_cart = (string)str_replace("-", "_",strtolower($plan['id_plan']));
        }
        
        // Manejar respuesta de ePayco (puede ser objeto o array)
        if (is_object($getPlans)) {
            // Si es objeto, acceder a los datos
            $plan_amount_epayco = $getPlans->data->amount ?? $getPlans->amount ?? null;
            $plan_id_epayco = $getPlans->data->id_plan ?? $getPlans->id_plan ?? null;
        } elseif (is_array($getPlans)) {
            // Si es array, acceder a los datos
            $plan_amount_epayco = $getPlans['data']['amount'] ?? $getPlans['amount'] ?? null;
            $plan_id_epayco = $getPlans['data']['id_plan'] ?? $getPlans['id_plan'] ?? null;
        } else {
            $plan_amount_epayco = null;
            $plan_id_epayco = null;
        }
        
        // Normalizar plan_id_epayco para comparación
        if ($plan_id_epayco) {
            $plan_id_epayco = (string)str_replace("-", "_",strtolower($plan_id_epayco));
        }
        
        // Si no encontramos el ID en la respuesta, proceder igualmente (el plan existe)
        if (!$plan_id_epayco) {
            return $this->process_payment_epayco($plans, $customer, $subscriptions, $order, $checkout);
        }
        
        if ($plan_id_cart == $plan_id_epayco) {
            try {
                if (intval($plan_amount_cart) == intval($plan_amount_epayco ?? 0)) {
                    return $this->process_payment_epayco($plans, $customer, $subscriptions, $order, $checkout);
                } else {
                    $result = $this->validateNewPlanData($plans, $order_id, $subscriptions,$customer, $order, $checkout);
                    return $result;
                }
            } catch (\Exception $exception) {
                return [
                    'success' => false,
                    'message' => $exception->getMessage()
                ];
            }
        } else {
            return [
                'success' => false,
                'message' => 'Plan ID does not match. Cart: ' . $plan_id_cart . ' vs ePayco: ' . ($plan_id_epayco ?? 'NOT FOUND')
            ];
        }
    }

    public function validateNewPlanData($plans, $order_id, $subscriptions,$customer, $order, $checkout)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'epayco_plans';
        $wc_order_product_lookup = $wpdb->prefix . "wc_order_product_lookup";
        /*valida la actualizacion del precio del plan*/
        foreach ($subscriptions as $key => $subscription) {
            $products = $subscription->get_items();
            $product_plan = $this->getPlan($products);
            $product_id_ = $product_plan['id'];
            $porciones = explode("-", $product_id_);
            $product_id = $porciones[0];
        }
        $currency = strtolower(get_woocommerce_currency());
        $plan_currency = strtolower($plans[0]['currency']);
        if($currency == $plan_currency){
            $newPlans[] = [
                'id_plan' => $product_plan['name'].$product_plan['id'].$plans[0]['amount'],
                'name' => $plans[0]['name'],
                'description' => $plans[0]['description'],
                'currency' => $plans[0]['currency'],
                'trial_days' => $plans[0]['trial_days'],
                'interval' => $plans[0]['interval'],
                'amount' => $plans[0]['amount'],
                'interval_count' => $plans[0]['interval_count']
            ];
            $getPlans = $this->getPlans($newPlans);
            if(!$getPlans){
                return $this->validatePlan(true, $order_id, $newPlans, $subscriptions, $customer, $order, false, false, null,$checkout);
            }else{
                return $this->validatePlan(false, $order_id, $newPlans, $subscriptions, $customer, $order, true, false, $getPlans,$checkout);
            }
        }

    }

    public function getTrialDays(\WC_Subscription $subscription)
    {
        $trial_days = "0";
        $trial_start = $subscription->get_date('start');
        $trial_end = $subscription->get_date('trial_end');

        if ($trial_end > 0)
            $trial_days = (string)(strtotime($trial_end) - strtotime($trial_start)) / (60 * 60 * 24);

        return $trial_days;
    }

    public function intervalAmount(\WC_Subscription $subscription)
    {
        return [
            "interval" => $subscription->get_billing_period(),
            "amount" => $subscription->get_total(),
            "interval_count" => $subscription->get_billing_interval()
        ];
    }

    public function getPlans(array $plans)
    {
        foreach ($plans as $key => $plan) {
            try {
                $planId = str_replace("-", "_",strtolower($plans[$key]['id_plan']));
                $plan = $this->sdk->plan->get($planId);
                
                // Verificar si el plan existe
                if (is_object($plan)) {
                    $planStatus = $plan->status ?? false;
                    if ($planStatus) {
                        unset($plans[$key]);
                        return $plan;
                    }
                } elseif (is_array($plan)) {
                    $planStatus = $plan['status'] ?? false;
                    if ($planStatus) {
                        unset($plans[$key]);
                        return $plan;
                    }
                }
                
                return false;

            } catch (\Exception $exception) {
                return false;
            }
        }
    }

    public function cleanCharacters($string)
    {
        $string = str_replace(' ', '-', $string);
        $patern = '/[^A-Za-z0-9\-]/';
        return preg_replace($patern, '', $string);
    }

    public function paramsBilling($subscriptions, $order, $checkout)
    {
        $data = [];
        $subscription = end($subscriptions);
        if ($subscription) {
            $data['token_card'] = $checkout['token'];
            $data['customer_id'] = $checkout['customer_id'];
            $data['name'] = $checkout['name'];
            $data['email'] = $checkout['email'];
            $data['phone'] = $checkout['cellphone'];
            $data['country'] = $checkout['countrytype'];
            $data['city'] = $checkout['country'];
            $data['address'] = $checkout['address'];
            $data['doc_number'] = $checkout['doc_number'];
            $data['type_document'] = $checkout['identificationtype'];
            return $data;
        } else {
            $redirect = array(
                'result' => 'fail',
                'redirect' => add_query_arg('order-pay', $order->id, add_query_arg('key', $order->order_key, get_permalink(woocommerce_get_page_id('pay'))))
            );
            wc_add_notice('EL producto que intenta pagar no es permitido', 'error');
            wp_redirect($redirect["redirect"]);
            die();
        }

    }

    public function process_payment_epayco(array $plans, array $customerData, $subscriptions, $order, $checkout)
    {
        $subsCreated = $this->subscriptionCreate($plans, $customerData, $checkout);
        
        if ($subsCreated->status ?? $subsCreated['status'] ?? false) {
            $subs = $this->subscriptionCharge($plans, $customerData, $checkout);
            
            foreach ($subs as $sub) {
                // Manejo de objeto o array
                if (is_array($sub)) {
                    $validation = $sub['success'] ?? $sub['status'] ?? false;
                    $errorMessage = $sub['data']['errors'] ?? 'Unknown error';
                } else {
                    $validation = $sub->success ?? $sub->status ?? false;
                    $errorMessage = $sub->data->errors ?? 'Unknown error';
                }
                
                if ($validation) {
                    $messageStatus = $this->handleStatusSubscriptions($subs, $subscriptions);
                    return $messageStatus;
                } else {
                    $response_status = [
                        'success' => false,
                        'message' => $errorMessage
                    ];
                    if (class_exists('WC_Logger')) {
                        $logger = wc_get_logger();
                        $logger->error("Subscription charge failed: " . wp_json_encode($response_status));
                    }
                }
            }
        } else {
            $errorMessage = $subsCreated->data->description ?? $subsCreated['data']['description'] ?? ($subsCreated->message ?? $subsCreated['message'] ?? 'Unknown error');
            $response_status = [
                'success' => false,
                'message' => $errorMessage,
            ];
            if (class_exists('WC_Logger')) {
                $logger = wc_get_logger();
                $logger->error("Subscription creation failed: " . wp_json_encode($response_status));
            }
        }
        return $response_status;
    }

    public function subscriptionCreate(array $plans, array $customer, $checkout)
    {
        $confirm_url = $checkout["confirm_url"];
        foreach ($plans as $plan) {
            try {
                $planId = str_replace("-", "_",strtolower($plan['id_plan']));
                $suscriptioncreted = $this->sdk->subscriptions->create(
                    [
                        "id_plan" => $planId,
                        "customer" => $customer['customer_id'],
                        "token_card" => $customer['token_card'],
                        "doc_type" => $customer['type_document'],
                        "doc_number" => $customer['doc_number'],
                        "url_confirmation" => $confirm_url,
                        "method_confirmation" => "POST"
                    ]
                );

                return $suscriptioncreted;

            } catch (\Exception $exception) {
                return [
                    'status' => false,
                    'message' => "subscriptionCreate ".$exception->getMessage()
                ];
            }
        }
    }

    public function subscriptionCharge(array $plans, array $customer, $checkout)
    {
        $subs = [];
        $confirm_url = $checkout["confirm_url"];
        foreach ($plans as $plan) {
            try {
                $planId = str_replace("-", "_",strtolower($plan['id_plan']));
                $subs[] = $this->sdk->subscriptions->charge(
                    [
                        "id_plan" => $planId,
                        "customer" => $customer['customer_id'],
                        "token_card" => $customer['token_card'],
                        "doc_type" => $customer['type_document'],
                        "doc_number" => $customer['doc_number'],
                        "ip" => $this->getCustomerIp(),
                        "url_confirmation" => $confirm_url,
                        "method_confirmation" => "POST"
                    ]
                );

            } catch (\Exception $exception) {
                return [
                    'status' => false,
                    'message' => "subscriptionCharge ".$exception->getMessage()
                ];
            }
        }

        return $subs;
    }

    public function handleStatusSubscriptions(array $subscriptionsStatus, array $subscriptions)
    {
        $count = 0;
        $messageStatus = [];
        $messageStatus['status'] = true;
        $messageStatus['success'] = false;
        $messageStatus['message'] = [];
        $messageStatus['estado'] = [];
        $messageStatus['ref_payco'] = [];
        $quantitySubscriptions = count($subscriptionsStatus);
        $orederStatus = array("Aprobada", "Aceptada", "Pendiente");
        
        foreach ($subscriptions as $subscription) {
            $sub = $subscriptionsStatus[$count];
            
            // Manejo de objeto o array
            if (is_array($sub)) {
                $isValid = $sub['success'] ?? $sub['status'] ?? false;
                $hasData = isset($sub['data']);
                $estado = $hasData ? ($sub['data']['estado'] ?? null) : null;
                $respuesta = $hasData ? ($sub['data']['respuesta'] ?? null) : null;
                $ref_payco = $hasData ? ($sub['data']['ref_payco'] ?? null) : null;
            } else {
                $isValid = $sub->success ?? $sub->status ?? false;
                $hasData = isset($sub->data);
                $estado = $hasData ? ($sub->data->estado ?? null) : null;
                $respuesta = $hasData ? ($sub->data->respuesta ?? null) : null;
                $ref_payco = $hasData ? ($sub->data->ref_payco ?? null) : null;
            }
            
            if ($isValid) {
                if ($estado) {
                    $messageStatus['ref_payco'] = array_merge($messageStatus['ref_payco'], [$ref_payco]);
                    $messageStatus['message'] = array_merge($messageStatus['message'], ["estado: {$respuesta}"]);
                    $messageStatus['estado'] = array_merge($messageStatus['estado'], [$estado]);
                    if (in_array($estado, $orederStatus)) {
                        $messageStatus['success'] = true;
                    }
                } else {
                    $messageStatus['ref_payco'] = array_merge($messageStatus['ref_payco'], ['Pendiente']);
                    $messageStatus['message'] = array_merge($messageStatus['message'], ["estado: Pendiente"]);
                    $messageStatus['estado'] = array_merge($messageStatus['estado'], ['Pendiente']);
                    $messageStatus['success'] = true;
                }
            }

            $count++;
        }
        return $messageStatus;

    }


    public function string_sanitize($string, $force_lowercase = true, $anal = false) {
        $strip = array("~", "`", "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "_", "=", "+", "[", "{", "]","}", "\\", "|", ":", "\"", "'", "&#8216;", "&#8217;", "&#8220;", "&#8221;", "&#8211;", "&#8212;","â€”", "â€“", "<", ">", "/", "?");
        $clean = trim(str_replace($strip, "", wp_strip_all_tags($string)));
        $clean = preg_replace('/\s+/', "_", $clean);
        $clean = ($anal) ? preg_replace("/[^a-zA-Z0-9]/", "", $clean) : $clean ;
        return $clean;
    }

    public function getCustomerIp(){
        $ipaddress = '';
        if (isset($_SERVER['HTTP_CLIENT_IP']))
            $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
        else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
            $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
        else if(isset($_SERVER['HTTP_X_FORWARDED']))
            $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
        else if(isset($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']))
            $ipaddress = $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
        else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
            $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
        else if(isset($_SERVER['HTTP_FORWARDED']))
            $ipaddress = $_SERVER['HTTP_FORWARDED'];
        else if(isset($_SERVER['REMOTE_ADDR']))
            $ipaddress = $_SERVER['REMOTE_ADDR'];
        else
            $ipaddress = 'UNKNOWN';
        return $ipaddress;
    }

    private function getCheckoutValues($order){
        $iva = 0;
        $ico = 0;

        foreach ($order->get_items('tax') as $item_id => $item) {
            $tax_label = trim(strtolower($item->get_label()));
            $tax_name = trim(strtolower($order->get_items_tax_classes()[0]));
            if ($tax_label == 'iva' || $tax_name == 'iva' ) {
                $iva = round($order->get_total_tax(), 2);
            }

            if ($tax_label == 'ico'|| $tax_name == 'ico') {
                $ico = round($order->get_total_tax(), 2);
            }
        }

        //$iva = $iva !== 0 ? $iva :$order->get_total_tax();
        //$base_tax = ($iva !== 0) ? ($order->get_total() - $order->get_total_tax()): (($ico !== 0) ? ($order->get_total() - $order->get_total_tax()): $order->get_subtotal() );
        $base_tax = $order->get_total() - $iva - $ico;

        return [
            "iva" => $iva,
            "ico" => $ico,
            "base_tax" => $base_tax,
            "total" => $order->get_total()
        ];

    }

    public function returnParameterToThankyouPage($transactionInfo, $payment, $order_id)
    {
        $x_amount = $transactionInfo['data']['x_amount']??$transactionInfo['data']['amount']??$transactionInfo['data'][0]['amount'];
        $x_amount_base = $transactionInfo['data']['x_amount_base']??$transactionInfo['data']['taxBaseClient']??$transactionInfo['data'][0]['taxBaseClient'];
        $x_cardnumber = $transactionInfo['data']['x_cardnumber']??$transactionInfo['data']['numberCard']??$transactionInfo['data'][0]['numberCard'];
        $x_id_invoice = $transactionInfo['data']['x_id_invoice']??$transactionInfo['data']['bill']??$transactionInfo['data'][0]['bill'];
        $x_franchise = $transactionInfo['data']['x_franchise']??$transactionInfo['data']['paymentMethod']??$transactionInfo['data'][0]['paymentMethod']??$transactionInfo['data']['bank']??$transactionInfo['data'][0]['bank'];
        $x_transaction_id = $transactionInfo['data']['x_transaction_id']??$transactionInfo['data']['referencePayco']??$transactionInfo['data'][0]['referencePayco'];
        $x_transaction_date = $transactionInfo['data']['x_transaction_date']??$transactionInfo['data']['transactionDate']??$transactionInfo['data'][0]['transactionDate'];
        $x_transaction_state = $transactionInfo['data']['x_transaction_state']??$transactionInfo['data']['status']??$transactionInfo['data'][0]['status'];
        $x_customer_ip = $transactionInfo['data']['x_customer_ip']??$transactionInfo['data']['ip']??$transactionInfo['data'][0]['ip'];
        $x_description = $transactionInfo['data']['x_description']??$transactionInfo['data']['description']??$transactionInfo['data'][0]['description'];
        $x_response= $transactionInfo['data']['x_response']??$transactionInfo['data']['status']??$transactionInfo['data'][0]['status'];
        $x_response_reason_text= $transactionInfo['data']['x_response_reason_text']??$transactionInfo['data']['response']??$transactionInfo['data'][0]['response'];
        $x_approval_code= $transactionInfo['data']['x_approval_code']??$transactionInfo['data']['authorization']??$transactionInfo['data'][0]['authorization'];
        $x_ref_payco= $transactionInfo['data']['x_ref_payco']??$transactionInfo['data']['referencePayco']??$transactionInfo['data'][0]['referencePayco'];
        $x_tax= $transactionInfo['data']['x_tax']??$transactionInfo['data']['tax']??$transactionInfo['data'][0]['tax'];
        $x_currency_code= $transactionInfo['data']['x_currency_code']??$transactionInfo['data']['currency']??$transactionInfo['data'][0]['currency'];
        switch ($x_response) {
            case 'Aceptada': {
                $iconUrl = $payment->epayco->hooks->gateway->getGatewayIcon('check.png');
                $iconColor = '#67C940';
                $message = $payment->storeTranslations['success_message'];
            }break;
            case 'Pendiente':
            case 'Pending':{
                $iconUrl = $this->epayco->hooks->gateway->getGatewayIcon('warning.png');
                $iconColor = '#FFD100';
                $message = $payment->storeTranslations['pending_message'];
            }break;
            default: {
                $iconUrl = $payment->epayco->hooks->gateway->getGatewayIcon('error.png');
                $iconColor = '#E1251B';
                $message = $payment->storeTranslations['fail_message'];
            }break;
        }

        $is_cash = false;
        if($x_franchise == 'EF'||
            $x_franchise == 'GA'||
            $x_franchise == 'PR'||
            $x_franchise == 'RS'||
            $x_franchise == 'SR'
        ){
            $x_cardnumber_ = null;
            $is_cash = true;
        }else{
            if($x_franchise == 'PSE' || $x_franchise == 'DP' || $x_franchise == 'DaviPlata' ){
                $x_cardnumber_ = null;
            }else{
                //$x_cardnumber_ = isset($x_cardnumber)?substr($x_cardnumber, -8):null;
                $x_cardnumber_ = $x_cardnumber;
            }
            $x_franchise = $x_franchise == 'DaviPlata' ? 'DP' : $x_franchise;
        }
        $lang = get_locale();
        $lang = explode('_', $lang);
        $lang = $lang[0];;
        $transaction = [
            'franchise_logo' => 'https://eks-ms-checkout-transaction-service.epayco.io/img/methods/'.$x_franchise.'.svg',
            'franchise' => $x_franchise,
            'x_amount_base' => $x_amount_base,
            'x_cardnumber' => $x_cardnumber_,
            'status' => $x_response,
            'type' => "",
            'refPayco' => $x_ref_payco,
            'factura' => $x_id_invoice,
            'descripcion_order' => $x_description,
            'valor' => $x_amount,
            'iva' => $x_tax,
            'estado' => $x_transaction_state,
            'response_reason_text' => $x_response_reason_text,
            'respuesta' => $x_response,
            'fecha' => $x_transaction_date,
            'currency' => $x_currency_code,
            'name' => '',
            'card' => '',
            'message' => $message,
            'error_message' => $payment->storeTranslations['error_message'],
            'error_description' => $payment->storeTranslations['error_description'],
            'payment_method'  => $payment->storeTranslations['payment_method'],
            'response'=> $payment->storeTranslations['response'],
            'dateandtime' => $payment->storeTranslations['dateandtime'],
            'authorization' => $x_approval_code,
            'iconUrl' => $iconUrl,
            'iconColor' => $iconColor,
            'epayco_icon' => $this->epayco->hooks->gateway->getGatewayIcon('logo_white.png'),
            'ip' => $x_customer_ip,
            'totalValue' => $payment->storeTranslations['totalValue'],
            'description' => $payment->storeTranslations['description'],
            'reference' => $payment->storeTranslations['reference'],
            'purchase' => $payment->storeTranslations['purchase'],
            'iPaddress' => $payment->storeTranslations['iPaddress'],
            'receipt' => $payment->storeTranslations['receipt'],
            'authorizations' => $payment->storeTranslations['authorization'],
            'paymentMethod'  => $payment->storeTranslations['paymentMethod'],
            'epayco_refecence'  => $payment->storeTranslations['epayco_refecence'],
            'code' => $payment->storeTranslations['code']??null,
            'is_cash' => $is_cash,
            'lang' => $lang
        ];

        return $transaction;
    }
}