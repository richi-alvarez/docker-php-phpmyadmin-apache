<?php

namespace Epayco\Woocommerce\Hooks;
use Epayco\Woocommerce\Hooks\Bank;
use Epayco\Woocommerce\Hooks\CreditCard;
use Epayco\Woocommerce\Hooks\Cash;
use Epayco\Woocommerce\Hooks\Token;
use Epayco\Woocommerce\Hooks\Customers;
use Epayco\Woocommerce\Hooks\Plan;
use Epayco\Woocommerce\Hooks\Subscriptions;
use Epayco\Woocommerce\Hooks\Daviplata;
use Epayco\Woocommerce\Hooks\Safetypay;
use Epayco\Woocommerce\Hooks\Transaction;
use Epayco\Woocommerce\Hooks\Authentication;

if (!defined('ABSPATH')) {
    exit;
}
class Epayco
{
    /**
     * Public key client
     * @var String
     */
    public $api_key;
    /**
     * Private key client
     * @var String
     */
    public $private_key;

    /**
     * test mode transaction
     * @var String
     */
    public $test;

    /**
     * lang client errors
     * @var String
     */
    public $lang;

    /**
     * CreditCard instance
     * @var CreditCard
     */
    public $charge;

    /*  * Token instance
     * @var Token
     */
    public $token;

    /**
     * Customers instance
     * @var Customers
     */
    public $customer;

    /**
     * Plan instance
     * @var Plan
     */
    public $plan;

    /**
     * Subscriptions instance
     * @var Subscriptions
     */
    public $subscriptions;

    /**
     * Bank instance
     * @var Bank
     */
    public $bank;

    /**
     * Cash instance
     * @var Cash
     */
    public $cash;

    /**
     * Daviplata instance
     * @var Daviplata
     */
    public $daviplata;


    /**
     * Safetypay instance
     * @var Safetypay
     */
    public $safetypay;

    /**
     * Transaction instance
     * @var Transaction
     */
    public $transaction;

    /**
     * Authentication instance
     * @var Authentication
     */
    public $authentication;

    /**
     * Constructor methods publics
     * @param array $options
     */
    public function __construct($options)
    {
        $this->api_key = $options["apiKey"];
        $this->private_key = $options["privateKey"];
        $this->test = $options["test"] ? "TRUE" : "FALSE";
        $this->lang = $options["lenguage"];

        $this->token = new Token($this);
        $this->customer = new Customers($this);
        $this->plan = new Plan($this);
        $this->subscriptions = new Subscriptions($this);
        $this->bank = new Bank($this);
        $this->cash = new Cash($this);
        $this->charge = new CreditCard($this);
        $this->daviplata = new Daviplata($this);
        $this->safetypay = new Safetypay($this);
        $this->transaction = new Transaction($this);
        $this->authentication = new Authentication($this);
    }
}