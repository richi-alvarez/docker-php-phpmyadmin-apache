<?php

namespace Epayco\Woocommerce\Hooks;

use ErrorException;
use Epayco\Woocommerce\Utils\Util;

if (!defined('ABSPATH')) {
    exit;
}
class Client
{
    const BASE_URL = "https://api.secure.payco.co";
    const BASE_URL_SECURE = "https://secure.payco.co";
    const ENTORNO = "/restpagos";
    const BASE_URL_APIFY = "https://apify.epayco.co";

    /**
     * Request api epayco
     * @param String $method method petition
     * @param String $url url request api epayco
     * @param String $api_key public key commerce
     * @param Object $data data petition
     * @param String $private_key private key commerce
     * @param String $test type petition production or testing
     * @param Boolean $switch type api petition
     * @return Object
     */
    public function request(
        $method,
        $url,
        $api_key,
        $data,
        $private_key,
        $test,
        $switch,
        $lang,
        $cash = null,
        $card = null,
        $apify = false
    ) {
        try{
            /**
             * Resources ip, traslate keys
             */
            $util = new Util();
            if ($method == "POST" && !is_null($data) && is_array($data) && !isset($data['extras_epayco'])) {
                $data['extras_epayco'] = ["extra5" => "P42"];
            }
            /**
             * Switch traslate keys array petition in secure
             */
            if ($apify && is_array($data)) {
                $data = $util->setKeys_apify($data);
            } else if ($switch && is_array($data)) {
                $data = $util->setKeys($data);
            }
            $cookie_name = $api_key . ($apify ? "_apify" : "");
            if (!isset($_COOKIE[$cookie_name])) {
                //  echo "Cookie named '" . $cookie_name . "' is not set!";
                $json = $this->authentication($api_key, $private_key, $apify);
                $bearer_token = false;
                if (isset($json['bearer_token'])) {
                    $bearer_token = $json['bearer_token'];
                } else if (isset($json['token'])) {
                    $bearer_token = $json['token'];
                }
                if (!$bearer_token) {
                    $msj = isset($json['message']) ? $json['message'] : "Error get bearer_token";
                    if ($msj == "Error get bearer_token" && isset($json['error'])) {
                        $msj = $json['error'];
                    }
                    throw new ErrorException($msj, 422);
                }
                $cookie_value = $bearer_token;
                setcookie($cookie_name, $cookie_value, time() + (60 * 14), "/");
                //  echo "token con login".$bearer_token;
            } else {
                $bearer_token = $_COOKIE[$cookie_name];
            }
            $headers = array("Content-Type" => "application/json", "Accept" => "application/json", "Type" => 'sdk-jwt', "Authorization" => 'Bearer ' . $bearer_token, "lang" => "PHP");
            if ($method == "GET") {
                if ($apify) {
                    $_url = Client::BASE_URL_APIFY . $url;
                } elseif ($switch) {
                    $_url = Client::BASE_URL_SECURE . Client::ENTORNO .  $url;
                } else {
                    $_url =Client::BASE_URL . $url;
                }

                $response = wp_remote_get($_url, [
                    'headers' => $headers,
                    'method'  => 'GET',
                    'timeout' => 15,
                ]);

            } elseif ($method == "POST") {
                 if (class_exists('WC_Logger')) {
                    $logger = wc_get_logger();
                    $logger->info("testMode: " . $test);
                }
                if ($apify) {
                    $url = Client::BASE_URL_APIFY . $url;
                } elseif ($switch) {
                    $data = $util->mergeSet($data, $test, $lang, $private_key, $api_key, $cash);

                    $url = Client::BASE_URL_SECURE . Client::ENTORNO . $url;
                } else {
                    if (!$card) {
                        $data["ip"] = isset($data["ip"]) ? $data["ip"] : getHostByName(getHostName());
                        $data["test"] = $test;
                    }
                    $url = Client::BASE_URL . $url;
                }

                $response = wp_remote_post($url, [
                    'body'    => wp_json_encode($data),
                    'headers' => $headers,
                    'method'  => 'POST',
                    'timeout' => 120,
                ]);
            }elseif ($method == "DELETE") {
                $response = wp_remote_request(Client::BASE_URL . $url, [
                    'headers' => $headers,
                    'method'  => 'DELETE',
                    'timeout' => 120,
                ]);
            }

            
            if (is_wp_error($response)) {
                return $this->getErrorFormat($response->get_error_message(), 500);
            }

            $body = wp_remote_retrieve_body($response);

            $data = json_decode($body, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                return $this->getErrorFormat('JSON decode error: ' . json_last_error_msg(), 500);
            }

            return $data;
        }catch (\Exception $e) {
            return $this->getErrorFormat($e->getMessage(), $e->getCode());
        }
    }

    public function authentication($api_key, $private_key, $apify)
    {
        $data = array(
            'public_key' => $api_key,
            'private_key' => $private_key
        );
        $headers = array("Content-Type" => "application/json", "Accept" => "application/json", "Type" => 'sdk-jwt', "lang" => "PHP");

        if ($apify) {
            $token = base64_encode($api_key . ":" . $private_key);
            $headers["Authorization"] = "Basic " . $token;
            $data = [];
        }
        $url = $apify ? Client::BASE_URL_APIFY . "/login" : Client::BASE_URL . "/v1/auth/login";

        $response = wp_remote_post($url, [
            'body'    => wp_json_encode($data),
            'headers' => $headers,
            'method'  => 'POST',
            'timeout' => 120,
        ]);

        if (is_wp_error($response)) {
            return $this->getErrorFormat($response->get_error_message(), 500);
        }

        $body = wp_remote_retrieve_body($response);

        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
           return $this->getErrorFormat('JSON decode error: ' . json_last_error_msg(), 500);
        }

        return $data;
    }

    public function getErrorFormat($message, $code)
    {
        switch ($code) {
            case 400:
                $error = isset($errors['message'])
                    ? $errors['message']
                    : (isset($errors['errors'][0])
                        ? $errors['errors'][0]
                        : "Solicitud incorrecta, por favor verifica los datos enviados");
                break;
            case 401:
                $error = isset($errors['message'])
                    ? $errors['message']
                    : (isset($errors['errors'][0])
                        ? $errors['errors'][0]
                        : "No autorizado, revisa tus credenciales");
                break;
            case 403:
                $error = isset($errors['message'])
                    ? $errors['message']
                    : (isset($errors['errors'][0])
                        ? $errors['errors'][0]
                        : "Acceso prohibido, no tienes permisos para esta acción");
                break;
            case 404:
                $error = "La ruta en la que estás realizando la petición no existe";
                break;
            case 405:
                $error = isset($errors['message'])
                    ? $errors['message']
                    : (isset($errors['errors'][0])
                        ? $errors['errors'][0]
                        : "Método no permitido en esta ruta");
                break;
            default:
                $error = "Error inesperado del servidor (HTTP {$code})";
                break;
        }

        $data = array(
            "status" => false,
            "message" => $error,
            "status_code" => $code,
            "data" => [],
        );
        $objectReturnError = (object)$data;
         if (class_exists('WC_Logger')) {
            $logger = wc_get_logger();
            $logger->info("ePaycoSdkError: " . wp_json_encode($objectReturnError));
        }
        return $objectReturnError;
    }

}