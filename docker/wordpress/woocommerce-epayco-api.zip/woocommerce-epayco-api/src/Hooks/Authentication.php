<?php

namespace Epayco\Woocommerce\Hooks;
use Epayco\Woocommerce\Hooks\Resource;
use ErrorException;

if (!defined('ABSPATH')) {
    exit;
}
class Authentication extends Resource
{
    /**
     * Authentication
     * @return object
     */
    public function Auth($apify = false)
    {
        $api_key = $this->epayco->api_key;
        $private_key = $this->epayco->private_key;
        $cookie_name = $api_key . ($apify ? "_apify" : "");
            if (!isset($_COOKIE[$cookie_name])) {
                //  echo "Cookie named '" . $cookie_name . "' is not set!";
                $json = $this->authentication($api_key, $private_key, $apify);
                $bearer_token = false;
                if (isset($json['bearer_token'])) {
                    $bearer_token = $json['bearer_token'];
                } else if (isset($json['token'])) {
                    $bearer_token = $json['token'];
                }
                if (!$bearer_token) {
                    $msj = isset($json['message']) ? $json['message'] : "Error get bearer_token";
                    if ($msj == "Error get bearer_token" && isset($json['error'])) {
                        $msj = $json['error'];
                    }
                    throw new ErrorException($msj, 422);
                }
                $cookie_value = $bearer_token;
                setcookie($cookie_name, $cookie_value, time() + (60 * 14), "/");
                //  echo "token con login".$bearer_token;
            } else {
                $bearer_token = $_COOKIE[$cookie_name];
            }
        return $bearer_token;
    }
}