<?php

namespace Epayco\Woocommerce\Gateways;

use Exception;
use WC_Order;

//use Epayco as EpaycoSdk;
use Epayco\Woocommerce\Hooks\Epayco as EpaycoSdk;
if (!defined('ABSPATH')) {
    exit;
}

class CheckoutGateway extends AbstractGateway
{
    /**
     * ID
     *
     * @const
     */
    public const ID = 'woo-epayco-checkout';

    /**
     * @const
     */
    public const CHECKOUT_NAME = 'checkout-epayco';

    /**
     * @const
     */
    public const WEBHOOK_API_NAME = 'WC_Epayco_Checkout_Gateway';

    /**
     * @const
     */
    public const LOG_SOURCE = 'Checkout Gateway';

    /*
    * @const
    */
    public $storeTranslations;
    public $iconAdmin;
    /**
     * @var EpaycoSdk
     */
    protected EpaycoSdk $epaycoSdk;
    /**
     * TicketGateway constructor
     */
    public function __construct()
    {
        parent::__construct();

        $this->adminTranslations = $this->epayco->adminTranslations->checkoutGatewaySettings;
        $this->storeTranslations = $this->epayco->storeTranslations->epaycoCheckout;
        $this->id        = self::ID;
        // $this->icon      = 'https://multimedia-epayco-preprod.s3.us-east-1.amazonaws.com/plugins-sdks/new/checkout.png';
        $this->iconAdmin = 'https://multimedia-epayco-preprod.s3.us-east-1.amazonaws.com/plugins-sdks/new/checkout.png';
        $this->title = $this->epayco->storeConfig->getGatewayTitle($this, 'Checkout ePayco');

        $this->init_form_fields();
        $this->payment_scripts($this->id);

        $this->description        = $this->adminTranslations['gateway_description'];
        $this->method_title       = $this->adminTranslations['method_title'];
        $this->method_description = $this->description;

        $this->epayco->hooks->gateway->registerUpdateOptions($this);
        $this->epayco->hooks->gateway->registerGatewayTitle($this);
        $this->epayco->hooks->gateway->registerThankYouPage($this->id, [$this, 'renderThankYouPage']);
        $this->epayco->hooks->gateway->registerGatewayReceiptPage($this->id, [$this, 'receiptPage']);
        $this->epayco->hooks->endpoints->registerApiEndpoint(self::WEBHOOK_API_NAME, [$this, 'webhook']);
        $lang = get_locale();
        $lang = explode('_', $lang);
        $lang = $lang[0];
        $this->epaycoSdk = new EpaycoSdk(
            [
                "apiKey" => $this->get_option('apiKey'),
                "privateKey" => $this->get_option('privateKey'),
                "lenguage" => strtoupper($lang),
                "test" => (bool)$this->get_option('environment')
            ]
        );

  

    }

    /**
     * Get checkout name
     *
     * @return string
     */
    public function getCheckoutName(): string
    {
        return self::CHECKOUT_NAME;
    }
    
    public function get_title() {
        $lang = substr(get_locale(), 0, 2);
        $description = ($lang === 'es')
            ? 'Otros métodos de pago.'
            : 'Other payment methods.';

        return sprintf(
            '<div class="epayco-title-wrapper">
                <img class="epayco-brand-icons" src="https://multimedia-epayco-preprod.s3.us-east-1.amazonaws.com/plugins-sdks/new/checkoutEpayco.png" alt="ePayco Icono" />
                <span class="epayco-text">
                    <span style="font-weight: bold;">%s</span>
                    <span style="color: #888;">%s</span>
                </span>
            </div>',
            esc_html($this->title),
            esc_html($description)
        );
    }

    /**
     * Init form fields for checkout configuration
     *
     * @return void
     */
    public function init_form_fields(): void
    {
        if ($this->addMissingCredentialsNoticeAsFormField()) {
            return;
        }

        parent::init_form_fields();

        $this->form_fields = array_merge($this->form_fields, [
            'config_header' => [
                'type'        => 'mp_config_title',
                'title'       => $this->adminTranslations['header_title'],
                'description' => $this->adminTranslations['header_description'],
            ],
            'card_homolog_validate' => $this->getHomologValidateNoticeOrHidden(),
            'card_settings'  => [
                'type'  => 'mp_card_info',
                'value' => [
                    'title'       => $this->adminTranslations['card_settings_title'],
                    'subtitle'    => $this->adminTranslations['card_settings_subtitle'],
                    'button_text' => $this->adminTranslations['card_settings_button_text'],
                    'button_url'  => admin_url('admin.php?page=epayco-settings'),
                    //'icon'        => 'ep-icon-badge-info',
                    'icon'        =>  $this->epayco->hooks->gateway->getGatewayIcon('icon-info.png'),
                    'color_card'  => '',
                    'size_card'   => 'ep-card-body-size',
                    'target'      => '_self',
                ],
            ],
            'enabled' => [
                'type'         => 'mp_toggle_switch',
                'title'        => $this->adminTranslations['enabled_title'],
                'subtitle'     => $this->adminTranslations['enabled_subtitle'],
                'default'      => 'default',
                'descriptions' => [
                    'enabled'  => $this->adminTranslations['enabled_enabled'],
                    'disabled' => $this->adminTranslations['enabled_disabled'],
                ],
            ],
            // 'title' => [
            //     'type'        => 'text',
            //     'title'       => $this->adminTranslations['title_title'],
            //     'description' => $this->adminTranslations['title_description'],
            //     'default'     => $this->adminTranslations['title_default'],
            //     'desc_tip'    => $this->adminTranslations['title_desc_tip'],
            //     'class'       => 'limit-title-max-length',
            // ],
            'epayco_type_checkout' => [
                'type'         => 'mp_toggle_switch',
                'title'        => $this->adminTranslations['epayco_type_checkout_title'],
                'subtitle'     => $this->adminTranslations['epayco_type_checkout_subtitle'],
                'default'      => 'yes',
                'descriptions' => [
                    'enabled'  => $this->adminTranslations['epayco_type_checkout_descriptions_enabled'],
                    'disabled' => $this->adminTranslations['epayco_type_checkout_descriptions_disabled'],
                ],
            ],
        ]);
    }

    /**
     * Added gateway scripts
     *
     * @param string $gatewaySection
     *
     * @return void
     */
    public function payment_scripts(string $gatewaySection): void
    {
        parent::payment_scripts($gatewaySection);
    }

    


    /**
     * Render gateway checkout template
     *
     * @return void
     */
    public function payment_fields(): void
    {
        $this->epayco->hooks->template->getWoocommerceTemplate(
            'public/checkout/epayco-checkout.php',
            $this->getPaymentFieldsParams()
        );
    }

    /**
     * Get Payment Fields params
     *
     * @return array
     */
    public function getPaymentFieldsParams(): array
    {
        return [
            'test_mode'                        => $this->epayco->storeConfig->isTestMode(),
            'test_mode_title'                  => $this->storeTranslations['test_mode_title'],
            'test_mode_description'            => $this->storeTranslations['test_mode_description'],
            'terms_and_conditions_label'       => $this->storeTranslations['terms_and_conditions_label'],
            'terms_and_conditions_description' => $this->storeTranslations['terms_and_conditions_description'],
            'terms_and_conditions_link_text'   => $this->storeTranslations['terms_and_conditions_link_text'],
            'and_the'   => $this->storeTranslations['and_the'],
            'terms_and_conditions_link_src'    => 'https://epayco.com/terminos-y-condiciones-generales/',
            'personal_data_processing_link_text'    => $this->storeTranslations['personal_data_processing_link_text'],
            'personal_data_processing_link_src'    => 'https://epayco.com/tratamiento-de-datos/',
            'site_id'                          => 'epayco',
            'logo' =>       $this->epayco->hooks->gateway->getGatewayIcon('logo-checkout.png'),
            'icon_info' =>       $this->epayco->hooks->gateway->getGatewayIcon('icon-info.png'),
            'icon_warning' =>       $this->epayco->hooks->gateway->getGatewayIcon('warning.png'),
        ];
    }

    /**
     * Process payment and create woocommerce order
     *
     * @param $order_id
     *
     * @return array
     */
    public function process_payment($order_id): array
    {
        $order = wc_get_order($order_id);
        try {
            $urlReceived =  $order->get_checkout_payment_url( true );
            return [
                'result'   => 'success',
                'redirect' => $urlReceived,
            ];

        }catch (\Exception $e) {
            return $this->processReturnFail(
                $e,
                $e->getMessage(),
                self::LOG_SOURCE,
                (array) $order,
                true
            );
        }
    }
   
    /**
     * Generate the epayco form
     *
     * @param mixed $order_id
     * @return string
     */
    public function generate_epayco_form( $order_id )
    {
        global $woocommerce;
            $order = new WC_Order($order_id);
            $descripcionParts = array();

            $iva = 0;
            $ico = 0;

            foreach ($order->get_items('tax') as $item_id => $item) {
                $tax_label = trim(strtolower($item->get_label()));
                $tax_name = trim(strtolower($order->get_items_tax_classes()[0]));
                if ($tax_label == 'iva' || $tax_name == 'iva' ) {
                    $iva = round($order->get_total_tax(), 2);
                }

                if ($tax_label == 'ico'|| $tax_name == 'ico') {
                    $ico = round($order->get_total_tax(), 2);
                }
            }

            //$iva = $iva !== 0 ? $iva :$order->get_total_tax();

            //$base_tax = ($iva !== 0) ? ($order->get_total() - $order->get_total_tax()): (($ico !== 0) ? ($order->get_total() - $order->get_total_tax()): $order->get_subtotal() );
            $base_tax = $order->get_total() - $iva - $ico;

            foreach ($order->get_items() as $product) {
                $clearData = str_replace('_', ' ', $this->string_sanitize($product['name']));
                $descripcionParts[] = $clearData;
            }

            $descripcion = implode(' - ', $descripcionParts);
            $currency = strtolower(get_woocommerce_currency());
            $testMode = $this->settings['epayco_testmode'] == "yes" ? true : false;
            $basedCountry = WC()->countries->get_base_country();
            $external = $this->settings['epayco_type_checkout']  == "true" ? 'standard' : 'onepage';
            $redirect_url = get_site_url() . "/";
            $redirect_url = add_query_arg('wc-api', get_class($this), $redirect_url);
            $redirect_url = add_query_arg('order_id', $order_id, $redirect_url);
            $myIp = $this->getCustomerIp();
            $lang = $this->settings['epayco_lang'] == 1 ? "es" : "en";
            if ($this->get_option('epayco_url_confirmation') == 0) {
                $confirm_url = $redirect_url . '&confirmation=1';
            } else {
                $confirm_url = get_permalink($this->get_option('epayco_url_confirmation'));
            }

            $name_billing = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
            $address_billing = $order->get_billing_address_1();
            $phone_billing = @$order->billing_phone;
            $email_billing = @$order->billing_email;

            //Busca si ya se restauro el stock
            /*if (!EpaycoOrder::ifExist($order_id)) {
                //si no se restauro el stock restaurarlo inmediatamente
                EpaycoOrder::create($order_id, 1);
                //$this->restore_order_stock($order->get_id(),"decrease");
            }*/
            $orderStatus = "pending";
            $current_state = $order->get_status();
            if ($current_state != $orderStatus) {
                $order->update_status($orderStatus);
                // $order->add_order_note(__('Reintento de pago iniciado - Formulario de ePayco generado', 'woo-epayco-gateway'));
                $order->save();
                //$this->restore_order_stock($order->get_id(),"decrease");
            }

            $tokenResponse = $this->epyacoBerarToken();
            $bearerToken = ($tokenResponse && isset($tokenResponse['token'])) ? $tokenResponse['token'] : '';
            $payload  = array(
                "name"=>substr($descripcion, 0, 30),
                "description"=>substr($descripcion, 0, 240),
                //"invoice"=>(string)$order->get_id(),
                "invoice" => (string)$order->get_id().date('YmdHis'),
                "currency"=>$currency,
                "amount"=>floatval($order->get_total()),
                "taxBase"=>floatval($base_tax),
                "tax"=>floatval($iva),
                "taxIco"=>floatval($ico),
                "country"=>$basedCountry,
                "lang"=>$lang,
                "confirmation"=>$confirm_url,
                "response"=>$redirect_url,
                "billing" => [
                    "name" => $name_billing,
                    "address" => $address_billing,
                    "email" => $email_billing,
                    "mobilePhone" => $phone_billing
                ],
                "autoclick"=> true,
                "ip"=>$myIp,
                "test"=>$testMode,
                 "extras" => [
                    "extra1" => (string)$order->get_id(),
                ],
                "extrasEpayco" => [
                    "extra5" => "P19"
                ],
                "epaycoMethodsDisable" => [],
                "method"=> "POST",
                "checkout_version"=>"2",
                "autoClick" => false,
                "noRedirectOnClose"=> true,
                "forceResponse"=>false,//mostrar detalle de orden
                "uniqueTransactionPerBill"=> false,
            );
            $path = "payment/session/create";
            $newToken['token'] =  $bearerToken;
            /* if (function_exists('wc_get_logger')) {
                $logger = wc_get_logger();
                $logger->error('ePayco AuCheckout payload: ' . json_encode($payload), ['source' => 'epayco']);
            }*/
            $epayco_status_session = $this->getEpaycoSessionId($path,$payload, $newToken);     
            if (is_array($epayco_status_session) && isset($epayco_status_session['success']) && $epayco_status_session['success']) {
                if (isset($epayco_status_session['data']) && is_array($epayco_status_session['data'])) {
                    $sessionId =  $epayco_status_session['data']['sessionId'];
                    $payload['sessionId'] = $sessionId;
                }
            }else{
                $messageError = (is_array($epayco_status_session) && isset($epayco_status_session['textResponse'])) ? $epayco_status_session['textResponse'] : '';
                $errorMessage = "";
                if (isset($epayco_status_session['data']['errors'])) {
                    $errors = $epayco_status_session['data']['errors'];
                    if(is_array($errors)){
                        foreach ($errors as $error) {
                            $errorMessage = $error['errorMessage'] . "\n";
                        }
                    }else{
                        $errorMessage = $errors. "\n";
                    }
                } elseif (isset($epayco_status_session['data']['error']['errores'])) {
                    $errores = $epayco_status_session['data']['error']['errores'];
                    foreach ($errores as $error) {
                        $errorMessage = $error['errorMessage'] . "\n";
                    }
                }
                //$processReturnFailMessage = $messageError . " " . $errorMessage;
                $processReturnFailMessage =  $errorMessage;
                 echo sprintf(
                '<div style="
                        display: flex;
                        align-items: center;
                        flex-direction: column;
                    ">
                    <div>
                    <img style="width: 80px;" src="https://multimedia-epayco-preprod.s3.us-east-1.amazonaws.com/plugins-sdks/warning.png" alt="" />
                    </div>
                    <div 
                    style="text-align: center;font-size: large;font-weight: 900;">
                        <p>"%s"</p>
                    </div>
                </div>',
                    $processReturnFailMessage
                );
            }
            $checkout =  base64_encode(json_encode([
                "sessionId"=>$payload['sessionId'],
                "external"=>$external,
                "test"=>$testMode
            ]));            
            echo sprintf(
                '<script
                    src="https://checkout.epayco.co/checkout-v2.js">
                </script>
                <script>
                    const params = JSON.parse(atob("%s"));
                    let {
                        sessionId,
                        external,
                        test
                    } = params; 
                    const checkout = ePayco.checkout.configure({
                        sessionId: sessionId,
                        type: external,
                        test: test
                    });
                    var bntPagar = document.getElementById("btn_epayco");
                    var openNewChekout = function () {
                        checkout.open();
                    }      
                    var openChekout = function () {
                        //bntPagar.style.pointerEvents = "none";
                        //bntPagar.style.opacity = "0.5";
                        openNewChekout();
                    }
                    bntPagar.addEventListener("click", openChekout);
                    setTimeout(function() {
                        openChekout();
                    }, 2000);
                </script>
            </form>
        </center>
        ',
            $checkout
        );
        wp_enqueue_script('epayco','https://checkout.epayco.co/checkout-v2.js', array(), '8.4.5', null);
        return '<form  method="post" id="appGateway">
		        </form>';
    }
    /**
     * Render Receipt  page
     *
     * @param $order_id
     */
    public function receiptPage($order_id): void
    {           
    echo ' <div class="loader-container">
                    <div class="loading"></div>
                </div>
                <p style="text-align: center;" class="epayco-title">
                    <span class="animated-points">Cargando métodos de pago</span>
                    <br><small class="epayco-subtitle"> </small>
                </p>';

            if ($this->settings['epayco_lang'] === "2") {
                $epaycoButtonImage = 'https://multimedia.epayco.co/epayco-landing/btns/Boton-epayco-color-Ingles.png';
            } else {
                $epaycoButtonImage = 'https://multimedia.epayco.co/epayco-landing/btns/Boton-epayco-color1.png';
            }
            echo '<p>       
                 <center>
                    <a id="btn_epayco" href="#">
                        <img src="' . $epaycoButtonImage . '">
                    </a>
                 </center> 
               </p>';
            echo $this->generate_epayco_form($order_id);
    }


    /**
     *
     * @string $string
     */
    public function string_sanitize($string):string
    {
        $strip = array("~", "`", "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "_", "=", "+", "[", "{", "]","}", "\\", "|", ";", ":", "\"", "'", "&#8216;", "&#8217;", "&#8220;", "&#8221;", "&#8211;", "&#8212;","â€”", "â€“", ",", "<", ".", ">", "/", "?");
        $clean = trim(str_replace($strip, "", wp_strip_all_tags($string)));
        $clean = preg_replace('/\s+/', "_", $clean);
        return $clean;
    }

    public function getCustomerIp(){
        $ipaddress = '';
        if (isset($_SERVER['HTTP_CLIENT_IP']))
            $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
        else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
            $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
        else if(isset($_SERVER['HTTP_X_FORWARDED']))
            $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
        else if(isset($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']))
            $ipaddress = $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
        else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
            $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
        else if(isset($_SERVER['HTTP_FORWARDED']))
            $ipaddress = $_SERVER['HTTP_FORWARDED'];
        else if(isset($_SERVER['REMOTE_ADDR']))
            $ipaddress = $_SERVER['REMOTE_ADDR'];
        else
            $ipaddress = 'UNKNOWN';
        return $ipaddress;
    }

    /**
     * Render thank you page
     *
     * @param $order_id
     */
    public function renderThankYouPage($order_id): void
    {
        $order        = wc_get_order($order_id);
        $ref_payco = sanitize_text_field($_REQUEST['ref_payco']);
        if(empty($ref_payco)){
            $order_id_explode = explode('=',$ref_payco);
            $order_id_rpl  = str_replace('?ref_payco','',$order_id_explode);
            $ref_payco =$order_id_rpl[0];
        }
        if (!$ref_payco)
        {
            $explode=explode('=',$order_id);
            $ref_payco=$explode[1];
        }

        if($ref_payco){
            $url = 'https://eks-checkout-service.epayco.io/validation/v1/reference/'.$ref_payco;
            $response = wp_remote_get(  $url );
            $body = wp_remote_retrieve_body( $response );
            $jsonData = @json_decode($body, true);
            $validationData = $jsonData['data'];
            $x_amount = trim($validationData['x_amount']);
            $x_amount_base = trim($validationData['x_amount_base']);
            $x_cardnumber = trim($validationData['x_cardnumber']);
            $x_id_invoice = trim($validationData['x_id_invoice']);
            $x_franchise = trim($validationData['x_franchise']);
            $x_transaction_id = trim($validationData['x_transaction_id']);
            $x_transaction_date = trim($validationData['x_transaction_date']);
            $x_transaction_state = trim($validationData['x_transaction_state']);
            $x_customer_ip = trim($validationData['x_customer_ip']);
            $x_description = trim($validationData['x_description']);
            $x_response= trim($validationData['x_response']);
            $x_response_reason_text= trim($validationData['x_response_reason_text']);
            $x_approval_code= trim($validationData['x_approval_code']);
            $x_ref_payco= trim($validationData['x_ref_payco']);
            $x_tax= trim($validationData['x_tax']);
            $x_currency_code= trim($validationData['x_currency_code']);
            switch ($x_response) {
                case 'Aceptada': {
                    $iconUrl = $this->epayco->hooks->gateway->getGatewayIcon('check.png');
                    $iconColor = '#67C940';
                    $message = $this->storeTranslations['success_message'];
                }break;
                case 'Pendiente':
                case 'Pending':{
                    $iconUrl = $this->epayco->hooks->gateway->getGatewayIcon('warning.png');
                    $iconColor = '#FFD100';
                    $message = $this->storeTranslations['pending_message'];
                }break;
                default: {
                    $iconUrl = $this->epayco->hooks->gateway->getGatewayIcon('error.png');
                    $iconColor = '#E1251B';
                    $message = $this->storeTranslations['fail_message'];
                    global $woocommerce;
                    $woocommerce->cart->empty_cart();
                    foreach ($order->get_items() as $item) {
                        // Get an instance of corresponding the WC_Product object
                        $product_id = $item->get_product()->id;
                        $product = $item->get_product();
                        $qty = $item->get_quantity(); // Get the item quantity
                        // Verificar si el producto es una variación
                        if ($product->is_type('variation')) {
                            WC()->cart->add_to_cart($product_id, $qty, $product->get_id(), $product->get_attributes());
                        }else{
                            WC()->cart->add_to_cart($product_id, (int)$qty);
                        }
                    }
                    wp_safe_redirect(wc_get_checkout_url());
                    exit();
                }break;
            }
            $donwload_url =get_site_url() . "/";
           // $donwload_url = add_query_arg( 'wc-api', self::WEBHOOK_DONWLOAD, $donwload_url );
            $donwload_url = add_query_arg( 'refPayco', $x_ref_payco, $donwload_url );
            $donwload_url = add_query_arg( 'fecha', $x_transaction_date, $donwload_url );
            $donwload_url = add_query_arg( 'franquicia', $x_franchise, $donwload_url );
            $donwload_url = add_query_arg( 'descuento', '0', $donwload_url );
            $donwload_url = add_query_arg( 'autorizacion', $x_approval_code, $donwload_url );
            $donwload_url = add_query_arg( 'valor', $x_amount, $donwload_url );
            $donwload_url = add_query_arg( 'estado', $x_response, $donwload_url );
            $donwload_url = add_query_arg( 'descripcion', $x_description, $donwload_url );
            $donwload_url = add_query_arg( 'respuesta', $x_response, $donwload_url );
            $donwload_url = add_query_arg( 'ip', $x_customer_ip, $donwload_url );
            $is_cash = false;
            
            if($x_franchise === 'EF' ||
                $x_franchise === 'GA' ||
                $x_franchise === 'PR' ||
                $x_franchise === 'RS' ||
                $x_franchise === 'SR'
            ){
                $x_cardnumber_ = null;
            }else{
                if($x_franchise === 'PSE'){
                    $x_cardnumber_ = null;
                }else{
                    $x_cardnumber_ = isset($x_cardnumber) ? substr($x_cardnumber, -8) : null;
                }
            }
            
            $transaction = [
                'franchise_logo' => 'https://eks-checkout-service.epayco.io/img/methods/' . $x_franchise . '.svg',
                'x_amount_base' => $x_amount_base,
                'x_cardnumber' => $x_cardnumber_,
                'status' => $x_response,
                'type' => "",
                'refPayco' => $x_ref_payco,
                'factura' => $x_id_invoice,
                'descripcion_order' => $x_description,
                'valor' => $x_amount,
                'iva' => $x_tax,
                'estado' => $x_transaction_state,
                'response_reason_text' => $x_response_reason_text,
                'respuesta' => $x_response,
                'fecha' => $x_transaction_date,
                'currency' => $x_currency_code,
                'name' => '',
                'card' => '',
                'message' => $message,
                'error_message' => $this->storeTranslations['error_message'],
                'error_description' => $this->storeTranslations['error_description'],
                'payment_method'  => $this->storeTranslations['payment_method'],
                'response'=> $this->storeTranslations['response'],
                'dateandtime' => $this->storeTranslations['dateandtime'],
                'authorization' => $x_approval_code,
                'iconUrl' => $iconUrl,
                'iconColor' => $iconColor,
                'epayco_icon' => $this->epayco->hooks->gateway->getGatewayIcon('logo_white.png'),
                'ip' => $x_customer_ip,
                'totalValue' => $this->storeTranslations['totalValue'],
                'description' => $this->storeTranslations['description'],
                'reference' => $this->storeTranslations['reference'],
                'purchase' => $this->storeTranslations['purchase'],
                'iPaddress' => $this->storeTranslations['iPaddress'],
                'receipt' => $this->storeTranslations['receipt'],
                'authorizations' => $this->storeTranslations['authorization'],
                'paymentMethod'  => $this->storeTranslations['paymentMethod'],
                'epayco_refecence'  => $this->storeTranslations['epayco_refecence'],
                'donwload_url' => $donwload_url,
                'donwload_text' => $this->storeTranslations['donwload_text'],
                'code' => $this->storeTranslations['code']??null,
                'is_cash' => $is_cash
            ];

            if (empty($transaction)) {
                return;
            }
            $this->epayco->orderMetadata->updatePaymentsOrderMetadata($order,[$ref_payco]);
            $this->epayco->hooks->template->getWoocommerceTemplate(
                'public/order/order-received.php',
                $transaction
            );
        }


    }

    public function getEpaycoSessionId($path,$data, $token)
    {
        if ($token) {
            $headers = [
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer '.$token['token'],
            ];
            return $this->epayco_realizar_llamada_api($path, $data, $headers);
        }
    }

    public function epyacoBerarToken()
    {
        $publicKey = $this->epayco->sellerConfig->getCredentialsPublicKeyPayment();
        $privateKey = $this->epayco->sellerConfig->getCredentialsPrivateKeyPayment();
        if(!isset($_COOKIE[$publicKey])) {
            $token = base64_encode($publicKey.":".$privateKey);
            $bearer_token = $token;
            $cookie_value = $bearer_token;
            setcookie($publicKey, $cookie_value, time() + (60 * 14), "/");
        }else{
            $bearer_token = $_COOKIE[$publicKey];
        }

        $headers = array(
            'Content-Type' => 'application/json',
            'Authorization' => "Basic ".$bearer_token
        );
        return $this->epayco_realizar_llamada_api("login",[],$headers);
    }

    public function epayco_realizar_llamada_api($path, $data, $headers, $afify = true, $method = 'POST') {
        if($afify){
            $url = 'https://apify.epayco.co/'.$path;
        }else{
            $url = 'https://secure.payco.co/restpagos/'.$path;
        }
        
        $response = wp_remote_post($url, array(
            'method'    => $method,
            'headers' => $headers,
            'data' => wp_json_encode($data),
            'timeout'   => 120,
        ));

        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            self::$logger->add($this->id, "Error al hacer la llamada a la API de ePayco: " . $error_message);
            error_log("Error al hacer la llamada a la API de ePayco: " . $error_message);
            return false;
        } else {
            $response_body = wp_remote_retrieve_body($response);
            $status_code = wp_remote_retrieve_response_code($response);

            if ($status_code == 200) {
                $data = json_decode($response_body, true);
                return $data;
            } else {
                self::$logger->add($this->id,"Error en la respuesta de la API de ePayco, código de estado: " . $status_code);
                error_log("Error en la respuesta de la API de ePayco, código de estado: " . $status_code);
                return false;
            }
        }
    }

    
    
}