<?php

namespace Epayco\Woocommerce\Gateways;

use Epayco\Woocommerce\Helpers\Form;
use Epayco\Woocommerce\Interfaces\EpaycoGatewayInterface;
use Epayco\Woocommerce\WoocommerceEpayco;
use Exception;
use Epayco\Woocommerce\Exceptions\RejectedPaymentException;
use WC_Payment_Gateway;
//use Epayco as EpaycoSdk;
use Epayco\Woocommerce\Hooks\Epayco as EpaycoSdk; 

abstract class AbstractGateway extends WC_Payment_Gateway implements EpaycoGatewayInterface
{
    public const ID = '';

    public const CHECKOUT_NAME = '';

    public const WEBHOOK_API_NAME = '';

    public const LOG_SOURCE = '';

    public array $adminTranslations;

    public WoocommerceEpayco $epayco;

    public ?string $epaycoToken = null;

    public array $epaycoPaymentMethods = [];

    /**
     * Payment model: 'gateway', 'agregador', or '' (single-model, no distinction needed)
     */
    public string $paymentModel = '';


    /**
     * Abstract Gateway constructor
     * @throws Exception
     */
    public function __construct()
    {
        global $epayco;

        $this->epayco = $epayco;
        
        // Initialize properties with default values
        $this->epaycoToken = null;
        $this->epaycoPaymentMethods = [
            'franquicias' => [
                'Visa' => 1,
                'MasterCard' => 1,
                'Amex' => 1,
                'Diners' => 1,
                'Codensa' => 1,
            ]
        ];
        
        $this->has_fields = true;
        $this->supports   = [ 'products', 'refunds' ];
        $this->init_settings();
    }

    /**
     * Init form fields for checkout configuration
     *
     * @return void
     */
    public function init_form_fields(): void
    {
        $this->form_fields = [];
    }

    /**
     * Override get_form_fields to inject model-aware enable/disable toggles
     * based on the configured integration model (gateway, agregador, ambos).
     *
     * @return array
     */
    public function get_form_fields(): array
    {
        $fields = parent::get_form_fields();

        if (empty($fields) || !isset($fields['enabled'])) {
            return $fields;
        }

        $modelType = $this->epayco->sellerConfig->getModelType();

        $gatewayToggle = [
            'type'         => 'mp_toggle_switch',
            'title'        => __('Activar para modelo Gateway', 'woo-epayco-api'),
            'subtitle'     => __('Habilitar este método de pago para el modelo Gateway.', 'woo-epayco-api'),
            'default'      => 'no',
            'descriptions' => [
                'enabled'  => __('El método de pago Gateway está <b>activado</b>.', 'woo-epayco-api'),
                'disabled' => __('El método de pago Gateway está <b>desactivado</b>.', 'woo-epayco-api'),
            ],
        ];

        $agregadorToggle = [
            'type'         => 'mp_toggle_switch',
            'title'        => __('Activar para modelo Agregador', 'woo-epayco-api'),
            'subtitle'     => __('Habilitar este método de pago para el modelo Agregador.', 'woo-epayco-api'),
            'default'      => 'no',
            'descriptions' => [
                'enabled'  => __('El método de pago Agregador está <b>activado</b>.', 'woo-epayco-api'),
                'disabled' => __('El método de pago Agregador está <b>desactivado</b>.', 'woo-epayco-api'),
            ],
        ];

        if ($modelType === 'gateway') {
            $fields['enabled'] = array_merge($fields['enabled'], $gatewayToggle);
            return $fields;
        }

        if ($modelType === 'agregador') {
            $result = [];
            foreach ($fields as $key => $field) {
                if ($key === 'enabled') {
                    $result['enabled_agregador'] = $agregadorToggle;
                } else {
                    $result[$key] = $field;
                }
            }
            return $result;
        }

        // ambos: gateway toggle + agregador toggle, one after the other
        if ($modelType === 'ambos') {
            $result = [];
            foreach ($fields as $key => $field) {
                if ($key === 'enabled') {
                    $result['enabled']           = array_merge($field, $gatewayToggle);
                    $result['enabled_agregador'] = $agregadorToggle;
                } else {
                    $result[$key] = $field;
                }
            }
            return $result;
        }

        return $fields;
    }

    /**
     * Added gateway scripts
     *
     * @param string $gatewaySection
     *
     * @return void
     */
    public function payment_scripts(string $gatewaySection): void
    {

        if ($this->canAdminLoadScriptsAndStyles($gatewaySection)) {
            $this->registerAdminScripts();
        }
        if ($this->canCheckoutLoadScriptsAndStyles()) {
            $this->registerCheckoutScripts();
        }
    }

    /**
     * Check if admin scripts and styles can be loaded
     *
     * @param string $gatewaySection
     *
     * @return bool
     */
    public function canAdminLoadScriptsAndStyles(string $gatewaySection): bool
    {
        return $this->epayco->hooks->admin->isAdmin() && ( $this->epayco->helpers->url->validatePage('wc-settings') &&
                $this->epayco->helpers->url->validateSection($gatewaySection)
            );
    }

    /**
     * Check if admin scripts and styles can be loaded
     *
     * @return bool
     */
    public function canCheckoutLoadScriptsAndStyles(): bool
    {
        return $this->epayco->hooks->gateway->isEnabled($this) &&
            ! $this->epayco->helpers->url->validateQueryVar('order-received');
    }

    /**
     * Register admin scripts
     *
     * @return void
     */
    public function registerAdminScripts()
    {
        $this->epayco->hooks->scripts->registerAdminScript(
            'wc_epayco_admin_components',
            $this->epayco->helpers->url->getJsAsset('admin/ep-admin-configs')
        );

        $this->epayco->hooks->scripts->registerAdminStyle(
            'wc_epayco_admin_components',
            $this->epayco->helpers->url->getCssAsset('admin/ep-admin-configs')
        );
    }

    /**
     * Register checkout scripts
     *
     * @return void
     */
    public function registerCheckoutScripts(): void
    {
        // Validate credentials before attempting authentication
        $public_key = $this->epayco->sellerConfig->getCredentialsPublicKeyPayment();
        $private_key = $this->epayco->sellerConfig->getCredentialsPrivateKeyPayment();
        
        $token = null;
        if (!empty($public_key) && !empty($private_key)) {
            try {
                $epaycoSdk = $this->getSdkInstance();
                $token = $epaycoSdk->authentication->Auth(true);
                $this->epaycoToken = $token;
                $paymentMethods = $this->getPaymentMethods($token);
                if (!empty($paymentMethods)) {
                    $this->epaycoPaymentMethods = $paymentMethods;
                }
            } catch (Exception $e) {
                // Log error and use default payment methods if authentication fails
                if (function_exists('wc_get_logger')) {
                    $logger = wc_get_logger();
                    $logger->error('ePayco Authentication Error: ' . $e->getMessage(), ['source' => 'epayco']);
                }
            }
        }
        
        // Use token if available, otherwise null
        $token = $this->epaycoToken;
        
        $this->epayco->hooks->scripts->registerCheckoutScript(
            'wc_epayco_checkout_crypto',
            $this->epayco->helpers->url->getJsAsset('checkouts/creditcard/crypto-v3.1.2')
        );

      
        $this->epayco->hooks->scripts->registerCheckoutScript(
            'wc_epayco_token_sdk',
            $this->epayco->helpers->url->getJsAsset('checkouts/creditcard/library')
            //"http://eks-cms-backend-platforms-service.epayco.iojs/library.js"
        );

        $this->epayco->hooks->scripts->registerCheckoutScript(
            'wc_epayco_checkout_components',
            $this->epayco->helpers->url->getJsAsset('checkouts/ep-plugins-components'),
            [
                'ep_json_url' => EP_PLUGIN_URL,
                'lang' => substr(get_locale(), 0, 2),
                'paymentMethods' => isset($this->epaycoPaymentMethods['franquicias']) ? $this->epaycoPaymentMethods['franquicias'] : [],
                'pcust_id' => $this->epayco->sellerConfig->getCredentialsPCustId(),
                'bearer_token' => $token ?? ''
            ]
        );

        $this->epayco->hooks->scripts->registerCheckoutStyle(
            'wc_epayco_checkout_components',
            $this->epayco->helpers->url->getCssAsset('checkouts/ep-plugins-components')
        );

        $this->epayco->hooks->scripts->registerCheckoutScript(
            'wc_epayco_checkout_update',
            $this->epayco->helpers->url->getJsAsset('checkouts/ep-checkout-update')
        );
        $script_detail_purchase = 'https://eks-cms-backend-platforms-service.epayco.io/plugin/DetailPurchase.js';
        //$script_detail_purchase = 'https://multimedia-epayco-preprod.s3.us-east-1.amazonaws.com/plugins-sdks/DetailPurchase.js';
        $this->epayco->hooks->scripts->registerCheckoutScript(
            'wc_epayco_thank_you_page',
            $script_detail_purchase
        );

        
    }

    /**
     * Render gateway checkout template
     *
     * @return void
     */
    public function payment_fields(): void
    {
    }

    /**
     * Validate gateway checkout form fields
     *
     * @return bool
     */
    public function validate_fields(): bool
    {
        return true;
    }

    /**
     * Process payment and create woocommerce order
     *
     * @param $order_id
     *
     * @return array
     * @throws Exception
     */
    public function process_payment($order_id): array
    {
        return [];
    }

    /**
     * Receive gateway webhook notifications
     *
     * @return void
     */
    public function webhook(): void
    {
        global $woocommerce;
        $order_id_info = trim(sanitize_text_field($_GET['order_id']));
        $order_id_explode = explode('=',$order_id_info);
        $order_id_rpl  = str_replace('?ref_payco','',$order_id_explode);
        $order_id = $order_id_rpl[0];
        $order = new \WC_Order($order_id);
        $data = Form::sanitizedGetData();
        $params = $data;
        if(is_null($params['x_ref_payco'])){
            $params = $_POST;
        }
        //$params = $_POST;
        $x_signature = trim(sanitize_text_field($params['x_signature']));
        $x_cod_transaction_state =intval(trim(sanitize_text_field($params['x_cod_transaction_state'])));
        $x_ref_payco = trim(sanitize_text_field($params['x_ref_payco']));
        $x_transaction_id = trim(sanitize_text_field($params['x_transaction_id']));
        $x_amount = trim(sanitize_text_field($params['x_amount']));
        $x_currency_code = trim(sanitize_text_field($params['x_currency_code']));
        $x_test_request = trim(sanitize_text_field($params['x_test_request']));
        $x_approval_code = trim(sanitize_text_field($params['x_approval_code']));
        $x_franchise = trim(sanitize_text_field($params['x_franchise']));
        $x_fecha_transaccion = trim(sanitize_text_field($params['x_fecha_transaccion']));
        $x_id_invoice = trim(sanitize_text_field($params['x_id_invoice']));
        if ($order_id != "" && $x_ref_payco != "") {
            $authSignature = $this->authSignature($x_ref_payco, $x_transaction_id, $x_amount, $x_currency_code);
        }
        if($x_franchise == 'DP' || $x_franchise == 'DaviPlata'){
            try {
                $bodyRequest= [
                    "filter"=>[
                        //>"referencePayco"=>$paymentInfo
                        "referenceClient"=>$x_id_invoice
                    ]
                ];
                $epaycoSdk = $this->getSdkInstance();
                $transactionDetails = $epaycoSdk->transaction->get($bodyRequest,true,"POST");
                $transactionInfo = json_decode(wp_json_encode($transactionDetails), true);
            } catch (Exception $e) {
                if (function_exists('wc_get_logger')) {
                    $logger = wc_get_logger();
                    $logger->error('ePayco DaviPlata Transaction Error: ' . $e->getMessage(), ['source' => 'epayco']);
                }
                return;
            }

            if (empty($transactionInfo)) {
                return;
            }

            if (is_array($transactionInfo)) {
                foreach ((array) $transactionInfo as $transaction) {
                    $daviplataTransactionData["data"] = $transaction;
                }
            }
            $transaciton = end($daviplataTransactionData["data"]);
            $x_ref_payco = $transaciton['referencePayco'];
            switch ($transaciton['status']) {
                case "Aceptada":
                    {
                        $x_cod_transaction_state = 1;
                    }
                    break;
                case "Rechazada":
                case "Fallida":
                case "abandonada":
                case "Cancelada":
                    {
                        $x_cod_transaction_state = 2;
                    }
                    break;
                case "Pendiente":
                case "retenido":
                    {
                        $x_cod_transaction_state = 3;
                    }
                    break;
                case "Reversada":
                    {
                        $x_cod_transaction_state = 6;
                    }
                    break;
                default:
                {
                    $x_cod_transaction_state = 0;
                }
            }
        }

        $isTestPluginMode = $this->epayco->storeConfig->isTestMode();
        $modo = $isTestPluginMode?'Prueba':'Producción';
        $current_state = $order->get_status();
        if(floatval($order->get_total()) == floatval($x_amount)){
            if($isTestPluginMode){
                $validation = true;
            }
            if(!$isTestPluginMode ){
                if($x_cod_transaction_state == 1){
                    $validation = true;
                }else{
                    if($x_cod_transaction_state != 1){
                        $validation = true;
                    }else{
                        $validation = false;
                    }
                }

            }
        }else{
            $validation = false;
        }

        if($authSignature == $x_signature){
            switch ($x_cod_transaction_state) {
                case 1: {
                    $message = 'Pago Proccesado ' .$x_ref_payco;
                    if($current_state !== "processing"){
                        if($current_state == "failed" ||
                            $current_state == "canceled"
                        ){
                            /*wc_reduce_stock_levels($order_id);
                            wc_increase_stock_levels($order_id);*/
                        }
                        $order->update_status("processing");
                    }

                }break;
                case 2:
                case 4:
                case 10:
                case 11:{
                    $message = 'Pago Cancelado ' .$x_ref_payco;
                    $order->update_status('cancelled');
                }break;
                case 3:
                case 7:{
                    $message = 'Pago Pendiente ' .$x_ref_payco;
                    $order->update_status("on-hold");
                }break;
                case 6: {
                    $message = 'Pago Reversada ' .$x_ref_payco;
                    $order->update_status('refunded');
                    $order->add_order_note('Pago Reversado');
                    //$this->restore_order_stock($order->get_id());
                    echo "6";
                } break;
                default: {
                    $message = 'Pago fallido ' .$x_ref_payco;
                    $order->update_status('failed');
                    $order->add_order_note('Pago fallido o abandonado');
                }
            }
            update_post_meta( $order->get_id(), 'refPayco', esc_attr($x_ref_payco));
            update_post_meta( $order->get_id(), 'modo', esc_attr($modo));
            update_post_meta( $order->get_id(), 'fecha', esc_attr($x_fecha_transaccion));
            update_post_meta( $order->get_id(), 'franquicia', esc_attr($x_franchise));
            update_post_meta( $order->get_id(), 'autorizacion', esc_attr($x_approval_code));
        }else{
            $message = 'Firma no valida';
        }
        echo esc_html($message);
        die();
    }

    public function authSignature($x_ref_payco, $x_transaction_id, $x_amount, $x_currency_code){
        $pCustId = $this->epayco->sellerConfig->getCredentialsPCustId();
        $pKey = $this->epayco->sellerConfig->getCredentialsPkey();
        $signature = hash('sha256',
            trim($pCustId).'^'
            .trim($pKey).'^'
            .$x_ref_payco.'^'
            .$x_transaction_id.'^'
            .$x_amount.'^'
            .$x_currency_code
        );
        return $signature;
    }

    protected function getSdkInstance()
    {

        $lang = get_locale();
        $lang = explode('_', $lang);
        $lang = $lang[0];
        $public_key = $this->epayco->sellerConfig->getCredentialsPublicKeyPayment();
        $private_key = $this->epayco->sellerConfig->getCredentialsPrivateKeyPayment();
        $isTestMode = $this->epayco->storeConfig->isTestMode()?"true":"false";
        return new EpaycoSdk(
            [
                "apiKey" => $public_key,
                "privateKey" => $private_key,
                "lenguage" => strtoupper($lang),
                "test" => $isTestMode
            ]
        );
    }


    /**
     * Determine checkout availability based on paymentModel.
     * - paymentModel === 'gateway'   → check 'enabled' option from original gateway settings
     * - paymentModel === 'agregador' → check 'enabled_agregador' option from original gateway settings
     * - paymentModel === ''          → default WooCommerce behaviour (single-model setup)
     *
     * @return bool
     */
    public function is_available(): bool
    {
        $settings  = get_option('woocommerce_' . static::ID . '_settings', []);
        $modelType = $this->paymentModel !== ''
            ? $this->paymentModel
            : ($this->epayco->sellerConfig->getModelType() ?? 'agregador');

        if ($modelType === 'agregador') {
            return ($settings['enabled_agregador'] ?? 'no') === 'yes';
        }

        if ($modelType === 'gateway') {
            return ($settings['enabled'] ?? 'no') === 'yes';
        }

        // 'ambos': visible si cualquiera de los dos modelos está activo
        return ($settings['enabled'] ?? 'no') === 'yes'
            || ($settings['enabled_agregador'] ?? 'no') === 'yes';
    }

    /**
     * Verify if the gateway is available
     *
     * @return bool
     */
    public static function isAvailable(): bool
    {
        return true;
    }

    /**
     * If the seller is homologated, it returns an array of an empty $form_fields field.
     * If not, then return a notice to inform that the seller must be homologated to be able to sell.
     *
     * @return array
     */
    protected function getHomologValidateNoticeOrHidden(): array
    {
        if ($this->epayco->sellerConfig->getHomologValidate()) {
            return [
                'type'  => 'title',
                'value' => '',
            ];
        }

        return [
            'type'  => 'mp_card_info',
            'value' => [
                'title'       => $this->epayco->adminTranslations->credentialsSettings['card_homolog_title'],
                'subtitle'    => $this->epayco->adminTranslations->credentialsSettings['card_homolog_subtitle'],
                'button_text' => $this->epayco->adminTranslations->credentialsSettings['card_homolog_button_text'],
                'button_url'  => admin_url('admin.php?page=epayco-settings'),
                'icon'        => 'https://multimedia.epayco.co/plugins-sdks/info.png',
                'color_card'  => '',
                'size_card'   => 'ep-card-body-payments-error',
                'target'      => '_blank',
            ]
        ];
    }


    /**
     * Add a "missing credentials" notice into the $form_fields array if there ir no credentials configured.
     * Returns true when the notice is added to the array, and false otherwise.
     *
     * @return bool
     */
    protected function addMissingCredentialsNoticeAsFormField(): bool
    {
        if (empty($this->epayco->sellerConfig->getCredentialsPublicKeyPayment()) || empty($this->epayco->sellerConfig->getCredentialsPrivateKeyPayment())) {
            $this->form_fields = [
                'card_info_validate' => [
                    'type'  => 'mp_card_info',
                    'value' => [
                        'title'       => '',
                        'subtitle'    => $this->epayco->adminTranslations->credentialsSettings['card_info_subtitle'],
                        'button_text' => $this->epayco->adminTranslations->credentialsSettings['card_info_button_text'],
                        'button_url'  => admin_url('admin.php?page=epayco-settings'),
                        'icon'        => 'https://multimedia.epayco.co/plugins-sdks/info.png',
                        'color_card'  => 'ep-alert-color-error',
                        'size_card'   => 'ep-card-body-size',
                        'target'      => '_self',
                    ]
                ]
            ];

            return true;
        }

        return false;
    }

    /**
     * Process if result is fail
     *
     * @param Exception $e
     * @param string $message
     * @param string $source
     * @param array $context
     * @param bool $notice
     *
     * @return array
     */
    public function processReturnFail(Exception $e, string $message, string $source, array $context = [], bool $notice = false): array
    {

        $errorMessages = [
            "Invalid test user email" => $this->epayco->storeTranslations->commonMessages['invalid_users'],
            "Invalid users involved" => $this->epayco->storeTranslations->commonMessages['invalid_users'],
            "Invalid operators users involved" => $this->epayco->storeTranslations->commonMessages['invalid_operators'],
            "exception" => $this->epayco->storeTranslations->buyerRefusedMessages['buyer_default'],
            "400" => $this->epayco->storeTranslations->buyerRefusedMessages['buyer_default'],
        ];

        foreach ($errorMessages as $keyword => $replacement) {
            if (strpos($message, $keyword) !== false) {
                $message = $replacement;
                break;
            }
        }

        if ($notice) {
            $this->epayco->helpers->notices->storeNotice($message, 'error');
        }

        return [
            'result'   => 'fail',
            'redirect' => '',
            'message'  => $message,
        ];
    }

    /**
     * Handle With Rejectec Payment Status
     *
     * @param $response
     *
     */
    public function handleWithRejectPayment($response)
    {
        if ($response['status'] === 'rejected') {
            $statusDetail = $response['status_detail'];

            $errorMessage = $this->getRejectedPaymentErrorMessage($statusDetail);

            //throw new RejectedPaymentException($errorMessage);
        }
    }

    /**
     * Get payment rejected error message
     *
     * @param string $statusDetail statusDetail.
     *
     * @return string
     */
    public function getRejectedPaymentErrorMessage($statusDetail)
    {
        return $this->epayco->storeTranslations->buyerRefusedMessages['buyer_' . $statusDetail] ??
            $this->epayco->storeTranslations->buyerRefusedMessages['buyer_default'];
    }

    /**
     * Process if result is fail
     *
     * @param string $message
     * @param mixed $context
     *
     * @return array
     */
    public function returnFail(string $message, $context): array
    {
        wc_add_notice($message, 'error');
        if (version_compare(WOOCOMMERCE_VERSION, '2.1', '>=')) {
            $redirect = array(
                'result'   => 'fail',
                'message'  => $message,
                'redirect' => add_query_arg('order-pay', $context->get_id(), add_query_arg('key', $context->order_key, get_permalink(woocommerce_get_page_id('pay'))))
            );
        } else {
            $redirect = array(
                'result'   => 'fail',
                'message'  => $message,
                'redirect' => add_query_arg('order', $context->get_id(), add_query_arg('key', $context->order_key, get_permalink(woocommerce_get_page_id('pay'))))
            );
        }

        return $redirect;
    }

    /**
     * Process blocks checkout data
     *
     * @param $prefix
     * @param $postData
     *
     * @return array
     */
    public function processBlocksCheckoutData($prefix, $postData): array
    {
        $checkoutData = [];

        foreach ($postData as $key => $value) {
            if (strpos($key, $prefix) === 0) {
                $newKey                  = substr($key, strlen($prefix));
                $checkoutData[ $newKey ] = $value;
            }
        }

        return $checkoutData;
    }

    /**
     * Normalize bracket-notation keys from WooCommerce Blocks REST payload
     * Converts "epayco_daviplata[cellphoneType]" => "cellphoneType"
     *
     * @param string $prefix The field prefix (e.g., 'epayco_daviplata')
     * @param array  $data   The flat key/value array from REST body
     *
     * @return array
     */
    protected function normalizeBlocksKeys(string $prefix, array $data): array
    {
        $result = [];
        foreach ($data as $key => $value) {
            if (preg_match('/^' . preg_quote($prefix, '/') . '\[(.+)\]$/', $key, $matches)) {
                $result[$matches[1]] = $value;
            } else {
                $result[$key] = $value;
            }
        }
        return $result;
    }

    /**
     * Extract checkout data from POST or REST API request
     * Handles both traditional form POST and WooCommerce Store API REST requests
     *
     * @param string $fieldPrefix The prefix for the form fields (e.g., 'epayco_subscription')
     * @param \WC_Order $order The WooCommerce order object
     *
     * @return array The extracted checkout data
     */
    protected function extractCheckoutData(string $fieldPrefix, \WC_Order $order): array
    {
        $checkout = [];
        $logger = wc_get_logger();
        $logSource = $this->id ?? 'Epayco_Gateway';

        // Method 1: Try traditional POST form data
        if (isset($_POST[$fieldPrefix])) {
            $checkout = Form::sanitizedPostData($fieldPrefix);
            $this->epayco->orderMetadata->markPaymentAsBlocks($order, "no");
            $logger->info("Checkout data from POST: " . wp_json_encode($checkout), ['source' => $logSource]);
            return $checkout;
        }

        // Method 2: Try REST API request body (for WooCommerce Blocks checkout)
        $request_body = file_get_contents('php://input');
        if (!empty($request_body)) {
            $data = json_decode($request_body, true);

            if (!empty($data)) {
                // Extract payment data from REST API extensions
                if (!empty($data['extensions'][$fieldPrefix])) {
                    $checkout = $this->normalizeBlocksKeys($fieldPrefix, $data['extensions'][$fieldPrefix]);
                    $this->epayco->orderMetadata->markPaymentAsBlocks($order, "yes");
                    $logger->info("Checkout data from REST extensions: " . wp_json_encode($checkout), ['source' => $logSource]);
                    return $checkout;
                }

                // Also check payment_data which WooCommerce might use
                if (!empty($data['payment_data'][$fieldPrefix])) {
                    $checkout = $this->normalizeBlocksKeys($fieldPrefix, $data['payment_data'][$fieldPrefix]);
                    $this->epayco->orderMetadata->markPaymentAsBlocks($order, "yes");
                    $logger->info("Checkout data from REST payment_data: " . wp_json_encode($checkout), ['source' => $logSource]);
                    return $checkout;
                }
            }
        }

        // Method 3: Fallback - extract from full POST data for blocks
        $all_post_data = Form::sanitizedPostData();
        $checkout = $this->processBlocksCheckoutData($fieldPrefix, $all_post_data);
        if (!empty($checkout)) {
            $this->epayco->orderMetadata->markPaymentAsBlocks($order, "yes");
            $logger->info("Checkout data from blocks POST filter: " . wp_json_encode($checkout), ['source' => $logSource]);
        }

        return $checkout;
    }


    /**
     * Generate custom toggle switch component
     *
     * @param string $key
     * @param array $settings
     *
     * @return string
     */
    public function generate_mp_toggle_switch_html(string $key, array $settings): string
{
    // Forzar valor por defecto 'yes' si no hay valor guardado
    $value = $this->epayco->hooks->options->getGatewayOption($this, $key, $settings['default'] ?? 'yes');
    if (empty($value)) {
        $value = 'yes';
    }
    return $this->epayco->hooks->template->getWoocommerceTemplateHtml(
        'admin/components/toggle-switch.php',
        [
            'field_key'   => $this->get_field_key($key),
            'field_value' => $value,
            'settings'    => $settings,
        ]
    );
}

    /**
     * Generate custom toggle switch component
     *
     * @param string $key
     * @param array $settings
     *
     * @return string
     */
    public function generate_mp_checkbox_list_html(string $key, array $settings): string
    {

        return $this->epayco->hooks->template->getWoocommerceTemplateHtml(
            'admin/components/checkbox-list.php',
            [
                'field_key' => $this->get_field_key($key),
                'settings'  => $settings,
            ]
        );
    }

    /**
     * Generate custom header component
     *
     * @param string $key
     * @param array $settings
     *
     * @return string
     */
    public function generate_mp_config_title_html(string $key, array $settings): string
    {
        return $this->epayco->hooks->template->getWoocommerceTemplateHtml(
            'admin/components/config-title.php',
            [
                'field_key'   => $this->get_field_key($key),
                'field_value' => null,
                'settings'    => $settings,
            ]
        );
    }

    /**
     * Generating custom actionable input component
     *
     * @param string $key
     * @param array $settings
     *
     * @return string
     */
    public function generate_mp_actionable_input_html(string $key, array $settings): string
    {
        return $this->epayco->hooks->template->getWoocommerceTemplateHtml(
            'admin/components/actionable-input.php',
            [
                'field_key'          => $this->get_field_key($key),
                'field_key_checkbox' => $this->get_field_key($key . '_checkbox'),
                'field_value'        => $this->epayco->hooks->options->getGatewayOption($this, $key),
                'enabled'            => $this->epayco->hooks->options->getGatewayOption($this, $key . '_checkbox'),
                'custom_attributes'  => $this->get_custom_attribute_html($settings),
                'settings'           => $settings,
                'allowedHtmlTags'    => $this->epayco->helpers->strings->getAllowedHtmlTags(),
            ]
        );
    }

    /**
     * Generating custom card info component
     *
     * @param string $key
     * @param array $settings
     *
     * @return string
     */
    public function generate_mp_card_info_html(string $key, array $settings): string
    {
        return $this->epayco->hooks->template->getWoocommerceTemplateHtml(
            'admin/components/card-info.php',
            [
                'field_key'   => $this->get_field_key($key),
                'field_value' => null,
                'settings'    => $settings,
            ]
        );
    }

    /**
     * Generating custom preview component
     *
     * @param string $key
     * @param array $settings
     *
     * @return string
     */
    public function generate_mp_preview_html(string $key, array $settings): string
    {
        return $this->epayco->hooks->template->getWoocommerceTemplateHtml(
            'admin/components/preview.php',
            [
                'field_key'   => $this->get_field_key($key),
                'field_value' => null,
                'settings'    => $settings,
            ]
        );
    }

    /**
     * Generating support link component
     *
     * @param string $key
     * @param array $settings
     *
     * @return string
     */
    public function generate_mp_support_link_html(string $key, array $settings): string
    {
        return $this->epayco->hooks->template->getWoocommerceTemplateHtml(
            'admin/components/support-link.php',
            [
                'field_key'   => $this->get_field_key($key),
                'field_value' => null,
                'settings'    => $settings,
            ]
        );
    }

    /**
     * Generating tooltip selection component
     *
     * @param string $key
     * @param array $settings
     *
     * @return string
     */
    public function generate_mp_tooltip_selection_html(string $key, array $settings): string
    {
        return $this->epayco->hooks->template->getWoocommerceTemplateHtml(
            'admin/components/tooltip-selection.php',
            [
                'field_key'   => $this->get_field_key($key),
                'field_value' => null,
                'settings'    => $settings,
            ]
        );
    }

    /**
     * Generating credits checkout example component
     *
     * @param string $key
     * @param array $settings
     *
     * @return string
     */
    public function generate_mp_credits_checkout_example_html(string $key, array $settings): string
    {
        return $this->epayco->hooks->template->getWoocommerceTemplateHtml(
            'admin/components/credits-checkout-example.php',
            [
                'field_key'   => $this->get_field_key($key),
                'field_value' => null,
                'settings'    => $settings,
            ]
        );
    }

    /**
     * Refund order
     *
     * @param $order_id
     */
    public function refundOrderGateway($order_id): void
    {
        try{
            $order = wc_get_order($order_id);
            $paymentInfo  = $this->epayco->hooks->order->getLastPaymentInfo($order);
            if(!$paymentInfo['success']){
                return;
            }
            $data = $paymentInfo['data'];
            $ref_payco = $data['referencePayco'];
            $epaycoSdk = $this->getSdkInstance();
            $bodyRequestRefund= [
                "referencePayco"=>$ref_payco
            ];
            $transactionRefund = $epaycoSdk->transaction->refund($bodyRequestRefund,"POST");
            $transactionInfo = json_decode(wp_json_encode($transactionRefund), true);
            $mensaje = '';
            if($transactionInfo['success']){
                $mensaje = 'Pago reembolsado con éxito';
                $order->add_order_note('ePayco: '.$mensaje);
            }else{
                $mensaje = $transactionInfo['data']['texto'];
                $order->add_order_note('ePayco: '.$mensaje);
            }
            if ( class_exists( 'WC_Logger' ) ) {
                $logger = new \WC_Logger();
                $logger->add( 'ePaycoRefundedTDC',  $mensaje );
            }
        }catch (\Exception $e){
            // Llamar API de la pasarela
            if ( class_exists( 'WC_Logger' ) ) {
                $logger = new \WC_Logger();
                $logger->add( 'ePaycoRefundedTDCError',  $e->getMessage() );
            }
            return;
        }
       
    }


    public function getPaymentMethods($token){
        return false;
        /*$bearerToken = 'Bearer ' . $token;
        $url = 'https://eks-cms-backend-platforms-service.epayco.io/payment/methods';
        $response = wp_remote_get($url, [
            'headers' => [
                'Authorization' => $bearerToken,
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
            ],
            'timeout' => 150,
        ]);
        if (is_wp_error($response)) {
            if (class_exists('WC_Logger')) {
                $logger = wc_get_logger();
                $logger->info("getPaymentMethods: " . wp_json_encode( $response->get_error_message()));
            }
            error_log('Error al obtener métodos de pago: ' . $response->get_error_message());
            return false;
        }
        $body = wp_remote_retrieve_body($response);
        $jsonData = @json_decode($body, true);
        if (!is_array($jsonData)) {
            error_log('Respuesta inválida al obtener métodos de pago');
            if (class_exists('WC_Logger')) {
                $logger = wc_get_logger();
                $logger->info("getPaymentMethods: Respuesta inválida al obtener métodos de pago" );
            }
            return false;
        }
        return $jsonData;        */
    }

}