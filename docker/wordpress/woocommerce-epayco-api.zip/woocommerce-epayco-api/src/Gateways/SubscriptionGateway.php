<?php

namespace Epayco\Woocommerce\Gateways;

use Epayco\Woocommerce\Helpers\Form;
use Epayco\Woocommerce\Helpers\PaymentStatus;
use Epayco\Woocommerce\Transactions\SubscriptionTransaction;


if (!defined('ABSPATH')) {
    exit;
}

class SubscriptionGateway extends AbstractGateway
{
    /**
     * @const
     */
    public const ID = 'woo-epayco-subscription';

    /**
     * @const
     */
    public const CHECKOUT_NAME = 'checkout-subscription';

    /**
     * @const
     */
    public const WEBHOOK_API_NAME = 'WC_Epayco_Subscription_Gateway';

    /**
     * @const
     */
    public const LOG_SOURCE = 'Epayco_SubscriptionGateway';

    public $storeTranslations;
    public $iconAdmin;

    /**
     * SubscriptionGateway constructor
     */
    public function __construct()
    {
        parent::__construct();

        $this->adminTranslations = $this->epayco->adminTranslations->subscriptionGatewaySettings;
        $this->storeTranslations = $this->epayco->storeTranslations->subscriptionCheckout;

        $this->id        = self::ID;
        $this->icon      = 'https://multimedia-epayco-preprod.s3.us-east-1.amazonaws.com/plugins-sdks/new/suscripciones.png';
        $this->iconAdmin = 'https://multimedia-epayco-preprod.s3.us-east-1.amazonaws.com/plugins-sdks/new/suscripciones.png';
        $this->method_description = $this->adminTranslations['gateway_method_description'];
        $defaultTitle = (substr(get_locale(), 0, 2) === 'es') ? 'Suscripciónes' : 'Subscriptions';
        $this->title = $this->epayco->storeConfig->getGatewayTitle($this, $defaultTitle);

        $this->init_form_fields();
        $this->supports = [
            'subscriptions',
            'subscription_suspension',
            'subscription_reactivation',
            'subscription_cancellation',
            'multiple_subscriptions'
        ];

        $this->description        = $this->adminTranslations['gateway_description'];
        $this->method_title       = $this->adminTranslations['gateway_method_title'];
        $this->method_description = $this->adminTranslations['gateway_method_description'];

        $this->epayco->hooks->gateway->registerUpdateOptions($this);
        $this->epayco->hooks->gateway->registerGatewayTitle($this);
        $this->epayco->hooks->gateway->registerThankYouPage($this->id, [$this, 'renderThankYouPage']);
        $this->epayco->hooks->endpoints->registerApiEndpoint(self::WEBHOOK_API_NAME, [$this, 'webhook']);

        // Nuevo registro del script autofill
        $this->epayco->hooks->scripts->registerCheckoutScript(
            'wc_epayco_subscription_autofill',
            $this->epayco->helpers->url->getJsAsset('checkouts/epayco-autofill')
        );
    }
    
    /**
     * Get checkout name
     *
     * @return string
     */
    public function getCheckoutName(): string
    {
        return self::CHECKOUT_NAME;
    }

    /**
     * Init form fields for checkout configuration
     *
     * @return void
     */
    public function init_form_fields(): void
    {
        if ($this->addMissingCredentialsNoticeAsFormField()) {
            return;
        }

        parent::init_form_fields();

        $this->form_fields = array_merge($this->form_fields, [
            'config_header' => [
                'type'        => 'mp_config_title',
                'title'       => $this->adminTranslations['header_title'],
                'description' => $this->adminTranslations['header_description'],
            ],
            'card_homolog_validate' => $this->getHomologValidateNoticeOrHidden(),
            'card_settings'  => [
                'type'  => 'mp_card_info',
                'value' => [
                    'title'       => $this->adminTranslations['card_settings_title'],
                    'subtitle'    => $this->adminTranslations['card_settings_subtitle'],
                    'button_text' => $this->adminTranslations['card_settings_button_text'],
                    'button_url'  => admin_url('admin.php?page=epayco-settings'),
                    'icon'        =>  $this->epayco->hooks->gateway->getGatewayIcon('icon-info.png'),
                    'color_card'  => '',
                    'size_card'   => 'ep-card-body-size',
                    'target'      => '_self',
                ],
            ],
            'enabled' => [
                'type'         => 'mp_toggle_switch',
                'title'        => $this->adminTranslations['enabled_title'],
                'subtitle'     => $this->adminTranslations['enabled_subtitle'],
                'default'      => 'no',
                'descriptions' => [
                    'enabled'  => $this->adminTranslations['enabled_descriptions_enabled'],
                    'disabled' => $this->adminTranslations['enabled_descriptions_disabled'],
                ],
            ],
            // 'title' => [
            //     'type'        => 'text',
            //     'title'       => $this->adminTranslations['title_title'],
            //     'description' => $this->adminTranslations['title_description'],
            //     'default'     => $this->adminTranslations['title_default'],
            //     'desc_tip'    => $this->adminTranslations['title_desc_tip'],
            //     'class'       => 'limit-title-max-length',
            // ],
            // 'card_info_helper' => [
            //     'type'  => 'title',
            //     'value' => '',
            // ]
        ]);
    }

    /**
     * Added gateway scripts
     *
     * @param string $gatewaySection
     *
     * @return void
     */
    public function payment_scripts(string $gatewaySection): void
    {
        parent::payment_scripts($gatewaySection);

        if ($this->canCheckoutLoadScriptsAndStyles()) {
            $this->registerCheckoutScripts();
        }
    }

    /**
     * Register checkout scripts
     *
     * @return void
     */
    public function registerCheckoutScripts(): void
    {
        parent::registerCheckoutScripts();
        $lang = get_locale();
        $lang = explode('_', $lang);
        $lang = $lang[0];
        
        // DIRECT ENQUEUE - Don't use registerCheckoutScript hook (it's too late)
        // Script 1: Page
        wp_enqueue_script(
            'wc_epayco_subscription_page',
            $this->epayco->helpers->url->getJsAsset('checkouts/subscription/ep-subscription-page'),
            [],
            $this->epayco->helpers->url->assetVersion(),
            true
        );
        
        // Script 2: Elements
        wp_enqueue_script(
            'wc_epayco_subscription_elements',
            $this->epayco->helpers->url->getJsAsset('checkouts/subscription/ep-subscription-elements'),
            [],
            $this->epayco->helpers->url->assetVersion(),
            true
        );
        
        // Script 3: Checkout (with localized params)
        // CRITICAL: Add jQuery dependency to ensure jQuery is loaded first
        wp_enqueue_script(
            'wc_epayco_subscription_checkout',
            $this->epayco->helpers->url->getJsAsset('checkouts/subscription/ep-subscription-checkout'),
            ['jquery'],  // REQUIRES jQuery to be loaded first
            $this->epayco->helpers->url->assetVersion(),
            true
        );
        
        // Localize script with parameters (MUST be after wp_enqueue_script)
        wp_localize_script(
            'wc_epayco_subscription_checkout',
            'wc_epayco_subscription_checkout_params',
            [
                'site_id' => 'epayco',
                'public_key_epayco' => $this->epayco->sellerConfig->getCredentialsPublicKeyPayment(),
                'lang' => $lang
            ]
        );
    }

    /**
     * Render gateway checkout template
     *
     * @return void
     */
    public function payment_fields(): void
    {
        if (class_exists('WC_Logger')) {
            $logger = wc_get_logger();
            
            // Session info
            $session_status = session_status() === PHP_SESSION_NONE ? 'NONE' : 'ACTIVE';
            $session_rendered = isset($_SESSION['woo_epayco_subscription_form_rendered']) ? 'YES' : 'NO';
            $logger->info("payment_fields() - Session: $session_status, Form rendered in session: $session_rendered", ['source' => 'woo-epayco-subscription']);
            
            // Backtrace to see where this is coming from
            $backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 10);
            foreach ($backtrace as $i => $trace) {
                $function = $trace['function'] ?? 'unknown';
                $file = basename($trace['file'] ?? '') ?? '';
                $line = $trace['line'] ?? 0;
                if (!empty($file)) {
                    $logger->info("[$i] $function() in $file:$line", ['source' => 'woo-epayco-subscription']);
                }
            }
        }
        
        $this->epayco->hooks->template->getWoocommerceTemplate(
            'public/checkout/subscription-checkout.php',
            $this->getPaymentFieldsParams()
        );
    }

    /**
     * Get Payment Fields params
     *
     * @return array
     */
    public function getPaymentFieldsParams(): array
    {
        $idioma = substr(get_locale(), 0, 2);
        if($idioma == 'es'){
            $termsAndCondiction = 'Términos y condiciones';
        }else{
            $termsAndCondiction = 'Terms and conditions';
        }
        if (strpos($this->storeTranslations['input_country_helper'], "Ciudad") !== false) {
            $city = "Ciudad";
        } else {
            $city = "City";
        }

        return [
            'test_mode'                        => $this->epayco->storeConfig->isTestMode(),
            'test_mode_title'                  => $this->storeTranslations['test_mode_title'],
            'test_mode_description'            => $this->storeTranslations['test_mode_description'],
            'test_mode_link_text'              => $this->storeTranslations['test_mode_link_text'],
            'card_detail'                      => $this->storeTranslations['card_detail'],
            //'test_mode_link_src'               => $this->links['docs_integration_test'],
            'card_form_title'                  => $this->storeTranslations['card_form_title'],
            'card_holder_name_input_label'     => $this->storeTranslations['card_holder_name_input_label'],
            'card_holder_name_input_helper'    => $this->storeTranslations['card_holder_name_input_helper'],
            'card_number_input_label'          => $this->storeTranslations['card_number_input_label'],
            'card_number_input_helper'         => $this->storeTranslations['card_number_input_helper'],
            'card_expiration_input_label'      => $this->storeTranslations['card_expiration_input_label'],
            'card_expiration_input_helper'     => $this->storeTranslations['card_expiration_input_helper'],
            'card_expiration_input_invalid_length' => $this->storeTranslations['input_helper_message_expiration_date_invalid_value'],
            'customer_data'                       => $this->storeTranslations['customer_data'],
            'card_security_code_input_label'   => $this->storeTranslations['card_security_code_input_label'],
            'card_security_code_input_helper'  => $this->storeTranslations['card_security_code_input_helper'],
            'card_security_code_input_invalid_length' => $this->storeTranslations['input_helper_message_security_code_invalid_length'],
            'card_customer_title'              => $this->storeTranslations['card_customer_title'],
            'card_document_input_label'        => $this->storeTranslations['card_document_input_label'],
            'card_document_input_helper'       => $this->storeTranslations['card_document_input_helper'],
            'card_holder_address_input_label'   => $this->storeTranslations['card_holder_address_input_label'],
            'card_holder_address_input_helper'  => $this->storeTranslations['card_holder_address_input_helper'],
            'card_holder_email_input_label'    => $this->storeTranslations['card_holder_email_input_label'],
            'card_holder_email_input_helper'   => $this->storeTranslations['card_holder_email_input_helper'],
            'card_holder_email_input_invalid'   => $this->storeTranslations['input_helper_message_card_holder_email'],
            'input_ind_phone_label'            => $this->storeTranslations['input_ind_phone_label'],
            'input_ind_phone_helper'           => $this->storeTranslations['input_ind_phone_helper'],
            'input_country_label'              => $this->storeTranslations['input_country_label'],
            'input_country_helper'             => $this->storeTranslations['input_country_helper'],
            'terms_and_conditions_label'       => $this->storeTranslations['terms_and_conditions_label'],
            'terms_and_conditions_description' => $this->storeTranslations['terms_and_conditions_description'],
            'terms_and_conditions_link_text'   => $this->storeTranslations['terms_and_conditions_link_text'],
            //'terms_and_conditions_link_text'   => $termsAndCondiction,
            'terms_and_conditions_link_src'    => 'https://epayco.com/terminos-y-condiciones-generales/',
            'personal_data_processing_link_text'    => $this->storeTranslations['personal_data_processing_link_text'],
            'and_the'   => $this->storeTranslations['and_the'],
            'personal_data_processing_link_src'    => 'https://epayco.com/tratamiento-de-datos/',
            'site_id'                          => 'epayco',
            'city'                          => $city,
            'customer_title'              => $this->storeTranslations['customer_title'],
            'test_mode_link_src'           => 'https://docs.epayco.co/testing',
            'logo' =>       $this->epayco->hooks->gateway->getGatewayIcon('logo-checkout.png'),
            'icon_info' =>       $this->epayco->hooks->gateway->getGatewayIcon('icon-info.png'),
            'icon_warning' =>       $this->epayco->hooks->gateway->getGatewayIcon('warning.png'),
        ];
    }

    /**
     * Process payment and create woocommerce order
     *
     * @param $order_id
     *
     * @return array
     */
    public function process_payment($order_id): array
    {
      
        $order = wc_get_order($order_id);
        $logger = wc_get_logger();
        
       
        
        try {
            $logger->info("Llamando a getCheckoutEpaycoSubscription()...", ['source' => self::LOG_SOURCE]);
            $checkout = $this->getCheckoutEpaycoSubscription($order);
            $logger->info("✓ getCheckoutEpaycoSubscription() completado", ['source' => self::LOG_SOURCE]);
            $logger->info("Checkout keys recibidas: " . implode(', ', array_keys($checkout)), ['source' => self::LOG_SOURCE]);

            parent::process_payment($order_id);

            // Token lookup with multiple fallbacks
            $checkout['token'] = $checkout['cardTokenId'] ?? $checkout['cardtokenid'] ?? '';
            
           
            // Try alternative POST locations (for backup)
            if (empty($checkout['token']) && !empty($_POST['epayco_session_token'])) {
                $checkout['token'] = sanitize_text_field($_POST['epayco_session_token']);
                error_log("[Epayco_SubscriptionGateway] [OK] Token found in POST[epayco_session_token]");
            }
            
          
            
            if (
                !empty($checkout['token'])
            ) {
                
                $checkout = $this->enrichCheckoutDataForSubscription($checkout, $order);
                
                $this->transaction = new SubscriptionTransaction($this, $order, $checkout);
                $redirect_url =get_site_url() . "/";
                $redirect_url = add_query_arg( 'wc-api', self::WEBHOOK_API_NAME, $redirect_url );
                $redirect_url = add_query_arg( 'order_id', $order_id, $redirect_url );
                $confirm_url = $redirect_url.'&confirmation=1';
                $checkout['confirm_url'] = $confirm_url;
                $checkout['response_url'] = $order->get_checkout_order_received_url();
                $response = $this->transaction->createSubscriptionPayment($order_id, $checkout);
                $response = json_decode(wp_json_encode($response), true);
                
              
                if (is_array($response) && isset($response['success']) && $response['success']) {
                    // Handle both string and array responses
                    $ref_payco = is_array($response['ref_payco']) ? $response['ref_payco'][0] : $response['ref_payco'];
                    $estado = is_array($response['estado']) ? $response['estado'][0] : $response['estado'];
                    $message = is_array($response['message']) ? $response['message'][0] : $response['message'];
                    
                    if (in_array(strtolower($estado),["pendiente","pending"])) {
                        $this->epayco->orderMetadata->updatePaymentsOrderMetadata($order, [$ref_payco]);
                        $order->update_status("on-hold");
                        $this->epayco->woocommerce->cart->empty_cart();
                        $urlReceived = $order->get_checkout_order_received_url();
                        $return = [
                            'result'   => 'success',
                            'redirect' => $urlReceived,
                        ];
                    }
                    if (in_array(strtolower($estado),["aceptada","acepted","aprobada"])) {
                        $this->epayco->orderMetadata->updatePaymentsOrderMetadata($order, [$ref_payco]);
                        $order->update_status("processing");
                        $this->epayco->woocommerce->cart->empty_cart();
                        $urlReceived = $order->get_checkout_order_received_url();
                        $return = [
                            'result'   => 'success',
                            'redirect' => $urlReceived,
                        ];
                    }if (in_array(strtolower($estado),["rechazada","fallida","cancelada","abandonada"])) {
                        $urlReceived = wc_get_checkout_url();
                        $return = [
                            'result'   => 'fail',
                            'message' => $message,
                            'redirect' => $urlReceived,
                        ];
                    }
                    return $return;
                }else{
                  
                    $messageError = isset($response['message']) ? $response['message'] : 'Unknown error';
                    $errorMessage = "";
                    if (isset($response['data']['errors'])) {
                        $errors = $response['data']['errors'];
                        foreach ($errors as $error) {
                            $errorMessage = $error['errorMessage'] . "\n";
                        }
                    } elseif (isset($response['data']['error']['errores'])) {
                        $errores = $response['data']['error']['errores'];
                        foreach ($errores as $error) {
                            $errorMessage = $error['errorMessage'] . "\n";
                        }
                    }
                    $processReturnFailMessage = $messageError. " " . $errorMessage;
                    return $this->returnFail($processReturnFailMessage, $order);
                }
            }else{
               
                
                $processReturnFailMessage = "Token incorrect ";
                return $this->returnFail($processReturnFailMessage, $order);
            }
        } catch (\Exception $e) {
           
            
            return $this->processReturnFail(
                $e,
                $e->getMessage(),
                self::LOG_SOURCE,
                (array) $order,
                true
            );
        }
    }

    /**
     * Get checkout epayco credits
     *
     * @param $order
     *
     * @return array
     */
    private function getCheckoutEpaycoSubscription($order): array
    {
        return $this->extractCheckoutData('epayco_subscription', $order);
    }

    /**
     * Enrich checkout data with WooCommerce order data to match paramsBilling() expectations
     * Maps subscription form fields to expected API field names
     *
     * @param array $checkout Checkout data from subscription form
     * @param \WC_Order $order WooCommerce order object
     *
     * @return array Enriched checkout data
     */
    private function enrichCheckoutDataForSubscription(array $checkout, \WC_Order $order): array
    {
       
        
        // 1. Normalize identificationType (PascalCase → lowercase)
        if (isset($checkout['identificationType'])) {
            $checkout['identificationtype'] = $checkout['identificationType'];
            unset($checkout['identificationType']);
        }
        
        // 2. Get country code from WooCommerce billing data
        $billing_country = $order->get_billing_country();
        $checkout['countrytype'] = $billing_country ?: 'CO'; // Default to Colombia if not set
        
        // 3. Get city from WooCommerce billing data
        $billing_city = $order->get_billing_city();
        $checkout['country'] = $billing_city ?: 'Bogotá'; // Default city if not set
        
        // 4. Ensure required fields exist
        $checkout['customer_id'] = $checkout['customer_id'] ?? '';
        
      
        return $checkout;
    }

    /**
     * Render thank you page
     *
     * @param $order_id
     */
    public function renderThankYouPage($order_id): void
    {
        $order        = wc_get_order($order_id);
        $lastPaymentId  =  $this->epayco->orderMetadata->getPaymentsIdMeta($order);
        $paymentInfo = json_decode(wp_json_encode($lastPaymentId), true);

        if (empty($paymentInfo)) {
            return;
        }
        $data = array(
            "filter" => array("referencePayco" => $paymentInfo),
            "success" =>true
        );
        $this->transaction = new SubscriptionTransaction($this, $order, []);
        //$transactionDetails = $this->transaction->sdk->transaction->get($paymentInfo);
        $transactionDetails = $this->transaction->sdk->transaction->get($data, true, "POST");
        $transactionInfo = json_decode(wp_json_encode($transactionDetails), true);

        if (empty($transactionInfo)) {
            return;
        }
        if(!$transactionInfo['success']){
            return;
        }
        $transaction = $this->transaction->returnParameterToThankyouPage($transactionInfo, $this, $order_id);

        if (empty($transaction)) {
            return;
        }

        $this->epayco->hooks->template->getWoocommerceTemplate(
            'public/order/order-received.php',
            $transaction
        );
    }
    
    /**
     * AJAX endpoint to save token from JavaScript localStorage
     * Called by JavaScript after token is generated
     * 
     * @return void
     */
}