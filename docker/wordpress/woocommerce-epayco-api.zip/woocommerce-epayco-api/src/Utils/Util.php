<?php
namespace Epayco\Woocommerce\Utils;
/**
 * Epayco library encrypt based in AES
 */
class Util
{
    const IV = "0000000000000000";
    const LENGUAGE = "php";
    
    public function setKeys($array)
    {
        $aux = array();
        $file = dirname(__FILE__). "/key_lang.json";
        $values = json_decode(file_get_contents($file), true);
        foreach ($array as $key => $value) {
            if (array_key_exists($key, $values)) {
                $aux[$values[$key]] = $value;
            } else {
                $aux[$key] = $value;
            }
        }
        return $aux;
    }


    public function setKeys_apify($array)
    {
        $aux = array();
        $file = dirname(__FILE__). "/key_lang_apify.json";
        $values = json_decode(file_get_contents($file), true);
        foreach ($array as $key => $value) {
            if (array_key_exists($key, $values)) {
                $aux[$values[$key]] = $value;
            } else {
                $aux[$key] = $value;
            }
        }
        return $aux;
    }



    public function mergeSet($data, $test, $lang, $private_key, $api_key, $cash)
    {
        $data["ip"] = isset($data["ip"]) ? $data["ip"] : getHostByName(getHostName());
        $data["test"] = $test;

        /**
         * Init AES
         * @var PaycoAes
         */

        $aes = new PaycoAes($private_key, self::IV, $lang);
        if (!$cash) {
            $data = $aes->encryptArray($data);
        }
        $adddata = array(
            "public_key" => $api_key,
            "i" => base64_encode(self::IV),
            "enpruebas" => $aes->encrypt($test),
            "lenguaje" => self::LENGUAGE,
            "p" => "",
        );
        return array_merge($data, $adddata);
    }
}