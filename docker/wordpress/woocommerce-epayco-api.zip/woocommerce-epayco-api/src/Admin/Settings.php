<?php

namespace Epayco\Woocommerce\Admin;

use Epayco\Woocommerce\Hooks\Order;
use Exception;
use Epayco\Woocommerce\Configs\Seller;
use Epayco\Woocommerce\Configs\Store;
use Epayco\Woocommerce\Hooks\Admin;
use Epayco\Woocommerce\Hooks\Endpoints;
use Epayco\Woocommerce\Hooks\Plugin;
use Epayco\Woocommerce\Hooks\Scripts;
use Epayco\Woocommerce\Helpers\CurrentUser;
use Epayco\Woocommerce\Helpers\Form;
use Epayco\Woocommerce\Helpers\Url;
use Epayco\Woocommerce\Translations\AdminTranslations;
use Epayco\Woocommerce\Funnel\Funnel;


if (!defined('ABSPATH')) {
    exit;
}

class Settings
{
    private const PRIORITY_ON_MENU = 90;
    private const NONCE_ID = 'ep_settings_nonce';
    private Admin $admin;
    private Endpoints $endpoints;
    private Order $order;
    private Plugin $plugin;
    private Scripts $scripts;
    private Seller $seller;
    private Store $store;
    private AdminTranslations $translations;
    private Url $url;
    private CurrentUser $currentUser;
    private Funnel $funnel;

    /**
     * Settings constructor
     *
     * @param Admin $admin
     * @param Endpoints $endpoints
     * @param Plugin $plugin
     * @param Scripts $scripts
     * @param Seller $seller
     * @param Store $store
     * @param AdminTranslations $translations
     * @param Url $url
     * @param CurrentUser $currentUser
     * @param Funnel $funnel
     */
    public function __construct(
        Admin $admin,
        Endpoints $endpoints,
        Order $order,
        Plugin $plugin,
        Scripts $scripts,
        Seller $seller,
        Store $store,
        AdminTranslations $translations,
        Url $url,
        CurrentUser $currentUser,
        Funnel $funnel
    )
    {
        $this->admin        = $admin;
        $this->endpoints    = $endpoints;
        $this->order        = $order;
        $this->plugin       = $plugin;
        $this->scripts      = $scripts;
        $this->seller       = $seller;
        $this->store        = $store;
        $this->translations = $translations;
        $this->url          = $url;
        $this->currentUser  = $currentUser;
        $this->funnel       = $funnel;

        $this->loadMenu();
        $this->loadScriptsAndStyles();
        $this->registerAjaxEndpoints();

        $this->plugin->registerOnPluginCredentialsUpdate(function () {
            $this->funnel->updateStepCredentials();
        });

        $this->plugin->registerOnPluginTestModeUpdate(function () {
            $this->funnel->updateStepPluginMode();
        });

        //$this->plugin->registerOnPluginStoreInfoUpdate(function () {
            $this->order->toggleSyncPendingStatusOrdersCron($this->store->getCronSyncMode());
        //});
    }

    /**
     * Load admin menu
     *
     * @return void
     */
    public function loadMenu(): void
    {
        $this->admin->registerOnMenu(self::PRIORITY_ON_MENU, [$this, 'registerEpaycoInWoocommerceMenu']);
    }

    /**
     * Load scripts and styles
     *
     * @return void
     */
    public function loadScriptsAndStyles(): void
    {
        if ($this->canLoadScriptsAndStyles()) {
            $this->scripts->registerAdminStyle(
                'epayco_settings_admin_css',
                $this->url->getCssAsset('admin/ep-admin-settings')
            );

            $this->scripts->registerAdminStyle(
                'epayco_admin_configs_css',
                $this->url->getCssAsset('admin/ep-admin-configs')
            );

            $this->scripts->registerAdminScript(
                'epayco_settings_admin_js',
                $this->url->getJsAsset('admin/ep-admin-settings'),
                [
                    'nonce'              => $this->generateNonce(self::NONCE_ID),
                    'show_advanced_text' => 'Show advanced options',
                    'hide_advanced_text' => 'Hide advanced options',
                ]
            );

        }

        if ($this->canLoadScriptsNoticesAdmin()) {
            $this->scripts->registerNoticesAdminScript();
        }
    }

    /**
     * Check if scripts notices can be loaded
     *
     * @return bool
     */
    public function canLoadScriptsNoticesAdmin(): bool
    {
        return $this->admin->isAdmin() && (
                $this->url->validateUrl('index') ||
                $this->url->validateUrl('plugins') ||
                $this->url->validatePage('wc-admin') ||
                $this->url->validatePage('wc-settings') ||
                $this->url->validatePage('epayco-settings')
            );
    }

    /**
     * Generate wp_nonce
     *
     * @param string $id
     *
     * @return string
     */
    public function generateNonce(string $id): string
    {
        $nonce = wp_create_nonce($id);
        if (!$nonce) {
            return '';
        }
        return $nonce;
    }

    /**
     * Register ajax endpoints
     *
     * @return void
     */
    public function registerAjaxEndpoints(): void
    {
        $this->endpoints->registerAjaxEndpoint('ep_update_test_mode', [$this, 'EpaycoUpdateTestMode']);
        $this->endpoints->registerAjaxEndpoint('ep_update_option_credentials', [$this, 'EpaycoUpdateOptionCredentials']);
        $this->endpoints->registerAjaxEndpoint('ep_get_payment_methods', [$this, 'EpaycoPaymentMethods']);
        $this->endpoints->registerAjaxEndpoint('ep_toggle_payment_method', [$this, 'EpaycoTogglePaymentMethod']);
        $this->endpoints->registerAjaxEndpoint('ep_validate_credentials_tips', [$this, 'EpaycoValidateCredentialsTips']);
        $this->endpoints->registerAjaxEndpoint('ep_validate_payment_tips', [$this, 'EpaycoValidatePaymentTips']);
    }

    /**
     * Check if scripts and styles can be loaded
     *
     * @return bool
     */
    public function canLoadScriptsAndStyles(): bool
    {
        return $this->admin->isAdmin() && (
                $this->url->validatePage('epayco-settings') ||
                $this->url->validateSection('woo-epayco')
            );
    }

    /**
     * Add Epayco submenu to Woocommerce menu
     *
     * @return void
     */
    public function registerEpaycoInWoocommerceMenu(): void
    {
        $this->admin->registerSubmenuPage(
            'woocommerce',
            'Epayco  Settings',
            'Epayco',
            'manage_options',
            'epayco-settings',
            [$this, 'EpaycoSubmenuPageCallback']
        );
    }

    /**
     * Show plugin configuration page
     *
     * @return void
     */
    public function EpaycoSubmenuPageCallback(): void
    {
        $headerTranslations      = $this->translations->headerSettings;
        $credentialsTranslations = $this->translations->credentialsSettings;
        $gatewaysTranslations    = $this->translations->gatewaysSettings;
        $testModeTranslations    = $this->translations->testModeSettings;

        $modelType     = $this->seller->getModelType();

        // Siempre pasar ambos conjuntos al template (para el swap JS y para "ambos")
        $gwPcustid    = $this->seller->getCredentialsPCustId();
        $gwPublicKey  = $this->seller->getCredentialsPublicKeyPayment();
        $gwPrivateKey = $this->seller->getCredentialsPrivateKeyPayment();
        $gwPKey       = $this->seller->getCredentialsPkey();

        $aggPcustid    = $this->seller->getAggCredentialsPCustId();
        $aggPKey       = $this->seller->getAggCredentialsPkey();
        $aggPublicKey  = $this->seller->getAggCredentialsPublicKey();
        $aggPrivateKey = $this->seller->getAggCredentialsPrivateKey();

        // Los 4 inputs principales muestran las credenciales del modelo activo
        if ($modelType === 'agregador') {
            $pcustid    = $aggPcustid;
            $pKey       = $aggPKey;
            $publicKey  = $aggPublicKey;
            $privateKey = $aggPrivateKey;
        } else {
            $pcustid    = $gwPcustid;
            $pKey       = $gwPKey;
            $publicKey  = $gwPublicKey;
            $privateKey = $gwPrivateKey;
        }
        $checkboxCheckoutTestMode  = $this->store->getCheckboxCheckoutTestMode();

        $testMode   = ($checkboxCheckoutTestMode === 'yes');

        $links      = [
            'epayco_credentials' =>'https://eks-dashboard-service.epayco.io/configuration'
        ];
        $allowedHtmlTags = array(
            'br' => array(),
            'b'  => array(),
            'a'  => array(
                'href'   => array(),
                'target' => array(),
                'class'  => array(),
                'id'     => array()
            ),
            'span' => array(
                'id'      => array(),
                'class'   => array(),
                'onclick' => array()
            ),
            'div' => array(
                'id'      => array(),
                'class'   => array(),
            ),
            'p' => array(
                'id'      => array(),
                'class'   => array(),
                'style' => array()
            ),
        );

        include dirname(__FILE__) . '/../../templates/admin/settings/settings.php';
    }

    /**
     * Save test mode options
     *
     * @return void
     */
    public function EpaycoUpdateTestMode(): void
    {
        $this->validateAjaxNonce();

        $checkoutTestMode    = Form::sanitizedPostData('input_mode_value');

        $validateCheckoutTestMode = ($checkoutTestMode === 'yes');

        $withoutTestCredentials = (
            $this->seller->getCredentialsPublicKeyPayment() === '' ||
            $this->seller->getCredentialsPrivateKeyPayment() === ''
        );

        if ( $withoutTestCredentials ) {
            wp_send_json_error($this->translations->updateCredentials['invalid_credentials_title'] .
                $this->translations->updateCredentials['for_test_mode']);
        }

        $this->store->setCheckboxCheckoutTestMode($checkoutTestMode);

        $this->plugin->executeUpdateTestModeAction();

        if ($validateCheckoutTestMode) {
            wp_send_json_success($this->translations->testModeSettings['title_message_test']);
        }

        wp_send_json_success($this->translations->testModeSettings['title_message_prod']);
    }


    /**
     * Save credentials, seller and store options
     *
     * @return void
     */
    public function EpaycoUpdateOptionCredentials(): void
    {
        try {
            $this->validateAjaxNonce();

            $p_cust_id   = Form::sanitizedPostData('p_cust_id')??$_POST['p_cust_id'];
            $p_key   = Form::sanitizedPostData('p_key')??$_POST['p_key'];
            $publicKey   = Form::sanitizedPostData('publicKey')??$_POST['publicKey'];
            $private_key   = Form::sanitizedPostData('private_key')??$_POST['private_key'];
            $model_type  = Form::sanitizedPostData('model_type') ?? 'agregador';
            $allowed_models = ['agregador', 'gateway', 'ambos'];
            if (!in_array($model_type, $allowed_models, true)) {
                $model_type = 'agregador';
            }
            $agg_p_cust_id   = Form::sanitizedPostData('agg_p_cust_id') ?? '';
            $agg_p_key       = Form::sanitizedPostData('agg_p_key') ?? '';
            $agg_public_key  = Form::sanitizedPostData('agg_public_key') ?? '';
            $agg_private_key = Form::sanitizedPostData('agg_private_key') ?? '';

            $this->seller->validatePublicKeyPayment('p_cust_id', $p_cust_id);
            $this->seller->validatePublicKeyPayment('p_key', $p_key);
            $this->seller->validatePublicKeyPayment('publicKey', $publicKey);
            $this->seller->validatePublicKeyPayment('private_key', $private_key);

            $errorParts = [];

            if ($model_type === 'gateway') {
                // Validar y guardar solo credenciales Gateway
                $gwValid = $this->seller->validateEpaycoCredentials($publicKey, $private_key);
                if (!$gwValid['status']) {
                    $errorParts[] = $this->translations->updateCredentials['invalid_credentials_gateway'];
                } else {
                    $this->seller->setHomologValidate($gwValid['status']);
                    $this->seller->setCredentialsPCustId($p_cust_id);
                    $this->seller->setCredentialsPkey($p_key);
                    $this->seller->setCredentialsPublicKeyPayment($publicKey);
                    $this->seller->setCredentialsPrivateKeyPayment($private_key);
                }

            } elseif ($model_type === 'agregador') {
                // Los 4 campos principales son del agregador — validar y guardar como agregador
                $aggValid = $this->seller->validateEpaycoCredentials($publicKey, $private_key);
                if (!$aggValid['status']) {
                    $errorParts[] = $this->translations->updateCredentials['invalid_credentials_agregador'];
                } else {
                    $this->seller->setAggCredentialsPCustId($p_cust_id);
                    $this->seller->setAggCredentialsPkey($p_key);
                    $this->seller->setAggCredentialsPublicKey($publicKey);
                    $this->seller->setAggCredentialsPrivateKey($private_key);
                }

            } elseif ($model_type === 'ambos') {
                // Validar Gateway (campos principales)
                $gwValid = $this->seller->validateEpaycoCredentials($publicKey, $private_key);
                if (!$gwValid['status']) {
                    $errorParts[] = $this->translations->updateCredentials['invalid_credentials_gateway'];
                }
                // Validar Agregador (campos secundarios)
                $aggValid2 = $this->seller->validateEpaycoCredentials($agg_public_key, $agg_private_key);
                if (!$aggValid2['status']) {
                    $errorParts[] = $this->translations->updateCredentials['invalid_credentials_agregador'];
                }
                if (empty($errorParts)) {
                    $this->seller->setHomologValidate($gwValid['status']);
                    $this->seller->setCredentialsPCustId($p_cust_id);
                    $this->seller->setCredentialsPkey($p_key);
                    $this->seller->setCredentialsPublicKeyPayment($publicKey);
                    $this->seller->setCredentialsPrivateKeyPayment($private_key);
                    $this->seller->setAggCredentialsPCustId($agg_p_cust_id);
                    $this->seller->setAggCredentialsPkey($agg_p_key);
                    $this->seller->setAggCredentialsPublicKey($agg_public_key);
                    $this->seller->setAggCredentialsPrivateKey($agg_private_key);
                }
            }

            if (!empty($errorParts)) {
                $response = [
                    'type'      => 'error',
                    'message'   => implode(' | ', $errorParts),
                    'subtitle'  => $this->translations->updateCredentials['invalid_credentials_subtitle'] . ' ',
                    'linkMsg'   => $this->translations->updateCredentials['invalid_credentials_link_message'],
                    'link'      => 'https://eks-dashboard-service.epayco.io/login',
                    'test_mode' => $this->store->getCheckboxCheckoutTestMode()
                ];
                wp_send_json_error($response);
            }

            $this->seller->setModelType($model_type);
            $this->plugin->executeUpdateCredentialAction();
            wp_send_json_success($this->translations->updateCredentials['credentials_updated']);


        } catch (Exception $e) {
            $response = [
                'type'      => 'error',
                'message'   => $e->getMessage(),
                'subtitle'  => $e->getMessage() . ' ',
                'linkMsg'   => '',
                'link'      => '',
                'test_mode' => $this->store->getCheckboxCheckoutTestMode()
            ];
            wp_send_json_error($response);
        }
    }

    /**
     * Get available payment methods
     *
     * @return void
     */
    public function EpaycoPaymentMethods(): void
    {
        try {
            $this->validateAjaxNonce();

            $paymentGateways            = $this->store->getAvailablePaymentGateways();
            $payment_gateway_properties = [];

            $modelType = $this->seller->getModelType();

            foreach ($paymentGateways as $paymentGateway) {
                $gateway = new $paymentGateway();

                $payment_gateway_properties[] = [
                    'id'               => $gateway->id,
                    'title_gateway'    => $gateway->title,
                    'description'      => $gateway->description,
                    'title'            => $gateway->title,
                    'model_type'       => $modelType,
                    'enabled_gateway'  => $gateway->settings['enabled'] ?? 'no',
                    'enabled_agregador'=> $gateway->settings['enabled_agregador'] ?? 'no',
                    'enabled'          => $gateway->settings['enabled'] ?? 'no',
                    'icon'             => $gateway->iconAdmin,
                    'link'             => admin_url('admin.php?page=wc-settings&tab=checkout&section=') . $gateway->id,
                    'badge_translator' => [
                        'yes'             => $this->translations->gatewaysSettings['enabled'],
                        'no'              => $this->translations->gatewaysSettings['disabled'],
                        'activate'        => $this->translations->gatewaysSettings['activate'],
                        'deactivate'      => $this->translations->gatewaysSettings['deactivate'],
                        'manage'          => $this->translations->gatewaysSettings['manage'],
                        'active'          => $this->translations->gatewaysSettings['active'],
                        'inactive'        => $this->translations->gatewaysSettings['inactive'],
                        'model_gateway'   => $this->translations->gatewaysSettings['model_gateway'],
                        'model_agregador' => $this->translations->gatewaysSettings['model_agregador'],
                    ],
                ];
            }

            wp_send_json_success($payment_gateway_properties);
        } catch (Exception $e) {
            $response = [
                'message' => $e->getMessage()
            ];

            wp_send_json_error($response);
        }
    }

    /**
     * Toggle a payment gateway enabled/disabled
     *
     * @return void
     */
    public function EpaycoTogglePaymentMethod(): void
    {
        try {
            $this->validateAjaxNonce();

            $gateway_id = Form::sanitizedPostData('gateway_id');
            $enabled    = Form::sanitizedPostData('enabled'); // 'yes' or 'no'
            $model      = Form::sanitizedPostData('model');

            if (!in_array($enabled, ['yes', 'no'], true)) {
                wp_send_json_error(['message' => 'Invalid enabled value']);
            }

            if (!in_array($model, ['gateway', 'agregador'], true)) {
                $model = 'gateway';
            }

            $paymentGateways = $this->store->getAvailablePaymentGateways();
            $found = false;

            foreach ($paymentGateways as $gatewayClass) {
                $gateway = new $gatewayClass();
                if ($gateway->id === $gateway_id) {
                    $gateway->init_settings();
                    if ($model === 'agregador') {
                        $gateway->settings['enabled_agregador'] = $enabled;
                    } else {
                        $gateway->settings['enabled'] = $enabled;
                    }

                    // Sync WooCommerce native 'enabled' flag so the admin UI
                    // and is_available() parent fallback stay consistent.
                    $modelType = $this->seller->getModelType();
                    if ($modelType === 'agregador') {
                        $gateway->settings['enabled'] = $gateway->settings['enabled_agregador'] ?? 'no';
                    } elseif ($modelType === 'ambos') {
                        $gwEnabled  = $gateway->settings['enabled']            ?? 'no';
                        $aggEnabled = $gateway->settings['enabled_agregador']  ?? 'no';
                        $gateway->settings['enabled'] = ($gwEnabled === 'yes' || $aggEnabled === 'yes') ? 'yes' : 'no';
                    }
                    // For 'gateway' model, settings['enabled'] is already set above.

                    update_option($gateway->get_option_key(), $gateway->settings);
                    $found = true;
                    break;
                }
            }

            if (!$found) {
                wp_send_json_error(['message' => 'Gateway not found: ' . $gateway_id]);
            }

            wp_send_json_success(['gateway_id' => $gateway_id, 'enabled' => $enabled]);

        } catch (Exception $e) {
            wp_send_json_error(['message' => $e->getMessage()]);
        }
    }

    /**
     * Validate credentials tips
     *
     * @return void
     */
    public function EpaycoValidateCredentialsTips(): void
    {
        $this->validateAjaxNonce();

        $gatewayConfigured   = $this->seller->getCredentialsPCustId()
                            && $this->seller->getCredentialsPkey()
                            && $this->seller->getCredentialsPublicKeyPayment()
                            && $this->seller->getCredentialsPrivateKeyPayment();

        $agregadorConfigured = $this->seller->getAggCredentialsPCustId()
                            && $this->seller->getAggCredentialsPkey()
                            && $this->seller->getAggCredentialsPublicKey()
                            && $this->seller->getAggCredentialsPrivateKey();

        if ($gatewayConfigured || $agregadorConfigured) {
            wp_send_json_success($this->translations->configurationTips['valid_credentials_tips']);
        }

        wp_send_json_error($this->translations->configurationTips['invalid_credentials_tips']);
    }

    /**
     * Validate store tips
     *
     * @return void
     */
    public function EpaycoValidatePaymentTips(): void
    {
        $this->validateAjaxNonce();

        $paymentGateways = $this->store->getAvailablePaymentGateways();
        $modelType       = $this->seller->getModelType();

        foreach ($paymentGateways as $gateway) {
            $gateway = new $gateway();

            $enabledGateway   = ($gateway->settings['enabled']            ?? 'no') === 'yes';
            $enabledAgregador = ($gateway->settings['enabled_agregador']  ?? 'no') === 'yes';

            $isEnabled = match ($modelType) {
                'gateway'   => $enabledGateway,
                'agregador' => $enabledAgregador,
                'ambos'     => $enabledGateway || $enabledAgregador,
                default     => $enabledGateway,
            };

            if ($isEnabled) {
                wp_send_json_success($this->translations->configurationTips['valid_payment_tips']);
            }
        }

        wp_send_json_error($this->translations->configurationTips['invalid_payment_tips']);
    }

    /**
     * Validate ajax nonce
     *
     * @return void
     */
    private function validateAjaxNonce(): void
    {
        $this->validateNonce(self::NONCE_ID, Form::sanitizedPostData('nonce'));
        $this->currentUser->validateUserNeededPermissions();
    }

    /**
     * Validate wp_nonce
     *
     * @param string $id
     * @param string $nonce
     *
     * @return void
     */
    public function validateNonce(string $id, string $nonce): void
    {
        if (!wp_verify_nonce($nonce, $id)) {
            wp_send_json_error('Forbidden', 403);
        }
    }

}